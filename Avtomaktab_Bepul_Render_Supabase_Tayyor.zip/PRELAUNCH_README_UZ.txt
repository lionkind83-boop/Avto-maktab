AVTO-MAKTAB — МАХФИЙ ТАЙЁРЛАШ / PRELAUNCH
======================================

Лойиҳа: Автомактаб учун ўқувчилар, гуруҳлар, тўловлар, давомат ва ҳисоботлар.
Бу версия оммага чиқаришдан ОЛДИНГИ текширув учун тайёрланган.

ҲОЗИРГИ ҲОЛАТ
- GitHub: lionkind83-boop/Avto-maktab (оммавий; ишлаб чиқаришдан олдин Private қилиш керак).
- Render сервис: avto-maktab — https://avto-maktab-1o3m.onrender.com, охирги deploy муваффақиятсиз (DATABASE_URL йўқ).
- Supabase: Avtomaktab, проект jwnsgnxeqmlzrntheyvc, PostgreSQL'да 8 жадвал мавжуд.
- Реал ўқувчилар ёки банк маълумотлари киритилмаган. Илтимос махфий маълумотларни кодга қўшманг.

УШБУ ТОПЛАМДА НИМА ҚИЛИНГАН
1. PRIVATE_PRELAUNCH=1 — барча асосий саҳифа ва API'ларга 503 ёпиқ режим, /api/health очиқ. REQUIRE_POSTGRES=1 бўлса, бу ёпиқ режим асосан ўзи ёқилади.
2. Render Free учун PostgreSQL талаб қилинади (REQUIRE_POSTGRES=1). SQLite фақат локал синовда.
3. RLS Supabase'da ўрнатилган, anon ва authenticated ролларга маълумотларга тўғридан-тўғри кириш ҳуқуқи йўқ.
4. Python 3.12 версияси белгиланди.
5. Захира нусхалари автоматик олинади деган нотўғри хабар тузатилди.

КЕЙИНГИ АМАЛЛАР (ОММАГА ЧИҚАРИШДАН ОЛДИН)
1. GitHub'даги лойиҳани PRIVATE қилинг. Ҳеч қачон .env файлларини, база паролини ёки DATABASE_URL'ни GitHub'га юкламанг.
2. Мана шу тўпламдаги кодни репозиторийга кўчиринг (асосий файллар ва public/ папкаси).
3. Render Environment'да:
     PRIVATE_PRELAUNCH=1
     REQUIRE_POSTGRES=1
     HTTPS_ONLY=1
     HOST=0.0.0.0
     DATABASE_URL=<Supabase Connect -> Session pooler URI, sslmode=require>
     BOOTSTRAP_ADMIN_USERNAME=admin
     BOOTSTRAP_ADMIN_PASSWORD=<12+ белгили, ҳарф ва рақамли, ФАҚАТ Render ичида>
   DATABASE_URL ва BOOTSTRAP_ADMIN_PASSWORD ни чатга юборманг.
4. Build: pip install -r requirements.txt
   Start: python server.py serve
   Health: /api/health
5. Локалда Python 3.12: python -m unittest discover -s tests -v
6. Синов: фақат фейк маълумот билан кириш, янги гуруҳ, ўқувчи, тўлов, давомат, ҳисобот ва ҳуқуқларни текширинг.
7. Расмий ишга туширишдан олдин Supabase жонли уланиш синови, захира/тиклаш режаси ва шахсий маълумотлар ҳимоясини қайта кўриб чиқинг.
8. Фақат ОММАГА ЧИҚАРИШГА АЛОҲИДА РУХСАТ берилганда PRIVATE_PRELAUNCH=0 қилинади.

МУҲИМ: HTTPS манзили бўлиши сайт оммага ишлайди дегани эмас. 
PRIVATE_PRELAUNCH=1 бўлса дастур (API ҳам) ёпиқ.
Бепул Render вақт-вақти билан ухлаши мумкин; бухгалтериянинг реал молиявий ҳисобини 24/7 кафолатсиз муҳитга топширманг.
