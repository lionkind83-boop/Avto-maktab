"""Contract exported with owner-supplied clauses, both appendices, QR metadata, no personal data in QR."""
import tempfile
import unittest
import json
from pathlib import Path
from unittest.mock import patch
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import server as app
import contract_pdf

class FullAgreementPDF(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  app.DATA_DIR=Path(self.tmp.name)
  app.DB=app.DATA_DIR/'db.sqlite3'
  app.init_db()
  self.u={'id':'director','username':'admin','role':'director','group_id':None}
  with app.managed_db() as c:
   c.execute('INSERT INTO groups(id,name,category,teacher,start_date,days,time,capacity,fee,status) VALUES(?,?,?,?,?,?,?,?,?,?)',('g1','B-27','B','Teacher','2026-10-12','Mon','9:00',20,3000000,'Фаол'))
 def tearDown(self):self.tmp.cleanup()
 def test_saved_requisites_33_clauses_two_appendices_qr_without_private_data(self):
  payload={'name':'Тест ўқувчи','phone':'+998900000000','groupId':'g1','join':'2026-10-12','fee':3000000,'status':'Ўқимоқда','contractNo':'SH-2026-0001','contractDate':'2026-10-12','pinfl':'12345678901234','passport':'AA1234567','serviceType':'Комплекс','theoryHours':'120','practicalHours':'20','paymentScheduleJson':json.dumps([{'date':'2026-11-01','amount':'1000000','note':'1-тўлов'}],ensure_ascii=False),'practiceLogJson':json.dumps([{'date':'2026-10-15','hours':'2','topic':'Бошқариш','instructor':'Тест'}],ensure_ascii=False)}
  with app.managed_db() as c:
   app.api_action(c,self.u,'PUT','/api/organization',{'name':'IDIAL MASTER MAKTAB','inn':'123456789','license':'L-001','director':'Тест директор','address':'Андижон','bank':'Банк','account':'2020800','mfo':'0011','phone':'0501122255','city':'Андижон','trainingAddress':'Андижон'})
   sid=app.api_action(c,self.u,'POST','/api/students',payload)['id']
   row=c.execute('SELECT * FROM students WHERE id=?',(sid,)).fetchone()
   group=c.execute('SELECT * FROM groups WHERE id=?',('g1',)).fetchone()
   self.assertEqual('2026-11-01',json.loads(row['payment_schedule_json'])[0]['date'])
   org=app.org_state(c)
   observed=[]
   real_widget=contract_pdf.QrCodeWidget
   def capture(*args,**kwargs):
    observed.append(args[0]);return real_widget(*args,**kwargs)
   with patch.object(contract_pdf,'QrCodeWidget',side_effect=capture):
    pdf=contract_pdf.generate_contract_pdf(row,group,org)
   self.assertTrue(pdf.startswith(b'%PDF-'))
   self.assertGreater(len(pdf),10000)
   self.assertEqual(len(contract_pdf.TEXT),33)
   self.assertEqual(len(observed),1)
   self.assertIn('SH-2026-0001',observed[0]);self.assertIn('12.10.2026',observed[0])
   self.assertNotIn('12345678901234',observed[0]);self.assertNotIn('AA1234567',observed[0]);self.assertNotIn('Тест ўқувчи',observed[0])

if __name__=='__main__':unittest.main()
