import datetime as dt
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.cookiejar import CookieJar
from http.server import ThreadingHTTPServer

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('school',ROOT/'server.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)

class TestOnline(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory()
  a.DATA_DIR=Path(cls.tmp.name);a.DB=a.DATA_DIR/'school.sqlite3'
  a.init_db()
  with a.db_connect() as c:
   for username,role,groupid in [('boss','director',None),('cash','cashier',None),('teach','teacher',None),('account','accountant',None)]:
    c.execute('INSERT INTO users(id,username,password_hash,role,group_id,created_at) VALUES(?,?,?,?,?,?)',
      (a.uid(),username,a.pwd_hash('StrongPassword2026'),role,groupid,a.now()))
  cls.httpd=ThreadingHTTPServer(('127.0.0.1',0),a.Handler)
  cls.thread=threading.Thread(target=cls.httpd.serve_forever,daemon=True);cls.thread.start()
  cls.url='http://127.0.0.1:'+str(cls.httpd.server_port)
 @classmethod
 def tearDownClass(cls):
  cls.httpd.shutdown();cls.httpd.server_close();cls.thread.join(timeout=2);cls.tmp.cleanup()
 def client(self):
  jar=CookieJar();return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
 def send(self,op,path,payload=None,method='GET',csrf=None):
  headers={};body=None
  if payload is not None:
   headers['Content-Type']='application/json';body=json.dumps(payload).encode()
  if csrf:headers['X-CSRF-Token']=csrf
  req=urllib.request.Request(self.url+path,data=body,headers=headers,method=method)
  try:
   with op.open(req,timeout=5) as resp:return resp.status,json.loads(resp.read())
  except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
 def login(self,op,user):
  code,out=self.send(op,'/api/login',{'username':user,'password':'StrongPassword2026'},'POST')
  self.assertEqual(200,code)
  return out['csrf']
 def test_roles_transactions_security(self):
  boss=self.client();cash=self.client();teach=self.client();account=self.client()
  self.assertEqual(401,self.send(boss,'/api/state')[0])
  bc=self.login(boss,'boss');cc=self.login(cash,'cash');ac=self.login(account,'account')
  g={'name':'B-77','category':'B тоифа','teacher':'Тест ўқитувчи','start':'2026-10-10','days':'Душ, Чор','time':'09:00','capacity':2,'fee':3000000,'status':'Фаол'}
  self.assertEqual(403,self.send(boss,'/api/groups',g,'POST')[0])
  code,x=self.send(boss,'/api/groups',g,'POST',bc);self.assertEqual(200,code);gid=x['id']
  self.assertEqual(403,self.send(cash,'/api/groups',g,'POST',cc)[0])
  s={'name':'Тест Ўқувчи','phone':'+998 90 123 45 67','groupId':gid,'join':'2026-10-10','fee':3000000,'status':'Ўқимоқда'}
  code,x=self.send(boss,'/api/students',s,'POST',bc);self.assertEqual(200,code);sid=x['id']
  p={'studentId':sid,'amount':2000000,'date':'2026-10-10','method':'Нақд','note':'биринчи'}
  code,x=self.send(cash,'/api/payments',p,'POST',cc);self.assertEqual(200,code);pid=x['id']
  self.assertEqual(400,self.send(cash,'/api/payments',{**p,'amount':2000000},'POST',cc)[0])
  self.assertEqual(403,self.send(cash,f'/api/payments/{pid}/void',{},'POST',cc)[0])
  self.assertEqual(200,self.send(account,f'/api/payments/{pid}/void',{},'POST',ac)[0])
  self.assertEqual(200,self.send(cash,'/api/payments',p,'POST',cc)[0])
  self.assertEqual(400,self.send(boss,f'/api/students/{sid}',None,'DELETE',bc)[0])
  with a.db_connect() as c:
   c.execute("UPDATE users SET group_id=? WHERE username='teach'",(gid,))
  tc=self.login(teach,'teach')
  state=self.send(teach,'/api/state')[1]
  self.assertEqual(0,len(state['payments']))
  self.assertEqual('',state['students'][0]['phone'])
  self.assertEqual(0,state['students'][0]['fee'])
  self.assertEqual(403,self.send(teach,'/api/users')[0])
  self.assertEqual(403,self.send(teach,'/api/payments',p,'POST',tc)[0])
  self.assertEqual(200,self.send(teach,'/api/attendance/upsert',{'groupId':gid,'date':'2026-10-10','entries':[{'studentId':sid,'status':'Келди'}]},'POST',tc)[0])
  self.assertEqual(403,self.send(teach,'/api/attendance/upsert',{'groupId':'other','date':'2026-10-10','entries':[]},'POST',tc)[0])
  self.assertEqual(200,self.send(boss,'/api/audit')[0])
  self.assertEqual(200,self.send(boss,'/api/backup')[0])
 def test_prelaunch_blocks_public_and_api_but_not_health(self):
  a.PRIVATE_PRELAUNCH=True
  try:
   op=self.client()
   code,result=self.send(op,'/api/state')
   self.assertEqual(code,503)
   self.assertIn('ёпиқ',result['error'])
   self.assertEqual(self.send(op,'/api/health')[0],200)
   with self.assertRaises(urllib.error.HTTPError) as err:
    op.open(self.url+'/',timeout=5)
   self.assertEqual(err.exception.code,503)
   self.assertIn('IDIAL MASTER MAKTAB',err.exception.read().decode('utf-8'))
  finally:
   a.PRIVATE_PRELAUNCH=False
 def test_z_password_change_invalidates_sessions(self):
  op=self.client();csrf=self.login(op,'account')
  self.assertEqual(403,self.send(op,'/api/change-password',{'oldPassword':'bad','newPassword':'NewPassword2026'},'POST',csrf)[0])
  self.assertEqual(200,self.send(op,'/api/change-password',{'oldPassword':'StrongPassword2026','newPassword':'NewPassword2026'},'POST',csrf)[0])
  self.assertEqual(401,self.send(op,'/api/state')[0])

if __name__=='__main__':unittest.main()
