import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('contracts_school',ROOT/'server.py')
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

class ContractRequisitesTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  a.DATA_DIR=Path(self.tmp.name)
  a.DB=a.DATA_DIR/'test.sqlite3'
  a.init_db()
  self.u={'id':'director-id','username':'boss','role':'director','group_id':None}
  self.teacher={'id':'teacher-id','username':'mentor','role':'teacher','group_id':'g1'}
  self.base={'name':'Фаррух Тест','phone':'+998901234567','groupId':'g1','join':'2026-10-12','fee':3000000,'status':'Ўқимоқда',
    'contractNo':'SH-2026-0001','contractDate':'2026-10-12','birthDate':'2001-04-02','passport':'AA1234567',
    'pinfl':'12345678901234','address':'Андижон вилояти','payerName':'Жасур Тест',
    'payerPhone':'+998901111111','courseStart':'2026-10-12','courseEnd':'2027-01-12',
    'paymentDue':'2026-11-12','paymentTerms':'Икки қисмда тўланади','contractNote':'Синов шартнома'}
  with a.managed_db() as c:
   c.execute('INSERT INTO groups(id,name,category,teacher,start_date,days,time,capacity,fee,status) VALUES(?,?,?,?,?,?,?,?,?,?)',('g1','B-34','B тоифа','Тест','2026-10-12','Душ','09:00',5,3000000,'Фаол'))
 def tearDown(self): self.tmp.cleanup()
 def test_create_read_update_and_migrate_preserves_records(self):
  with a.managed_db() as c:
   sid=a.api_action(c,self.u,'POST','/api/students',self.base)['id']
   result=a.as_state(c,self.u)['students'][0]
   self.assertEqual('SH-2026-0001',result['contractNo'])
   self.assertEqual('AA1234567',result['passport'])
   self.assertEqual('12345678901234',result['pinfl'])
   self.assertEqual('Икки қисмда тўланади',result['paymentTerms'])
   teach=a.as_state(c,self.teacher)['students'][0]
   self.assertEqual('',teach['passport'])
   self.assertEqual('',teach['pinfl'])
   self.assertEqual('',teach['contractNo'])
   update={**self.base,'contractNo':'SH-2026-0002','paymentTerms':'Ҳар ой'}
   self.assertEqual(sid,a.api_action(c,self.u,'PUT','/api/students/'+sid,update)['id'])
  a.init_db() # schema migration is safe to rerun
  with a.managed_db() as c:
   r=a.as_state(c,self.u)['students'][0]
   self.assertEqual('SH-2026-0002',r['contractNo'])
   self.assertEqual('Ҳар ой',r['paymentTerms'])
 def test_duplicate_number_and_bad_pinfl_rejected(self):
  with a.managed_db() as c:
   a.api_action(c,self.u,'POST','/api/students',self.base)
   with self.assertRaisesRegex(a.ApiError,'аввал киритилган'):
    a.api_action(c,self.u,'POST','/api/students',{**self.base,'contractNo':'sh-2026-0001'})
   with self.assertRaisesRegex(a.ApiError,'14 та рақам'):
    a.student_fields({**self.base,'pinfl':'12'})
   with self.assertRaisesRegex(a.ApiError,'тугаш санаси'):
    a.student_fields({**self.base,'courseEnd':'2026-10-01'})
 def test_legacy_missing_contract_fields(self):
  legacy={k:self.base[k] for k in ('name','phone','groupId','join','fee','status')}
  with a.managed_db() as c:
   sid=a.api_action(c,self.u,'POST','/api/students',legacy)['id']
   r=a.as_state(c,self.u)['students'][0]
   self.assertEqual('',r['contractNo'])
   self.assertEqual('',r['address'])
   self.assertEqual(sid,r['id'])

if __name__=='__main__':unittest.main()
