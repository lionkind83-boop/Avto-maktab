import importlib.util
import json
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
from http.cookiejar import CookieJar
from http.server import ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('pdf_school_test', ROOT / 'server.py')
a = importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

class PDFDownloadTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory()
  a.DATA_DIR=Path(cls.tmp.name);a.DB=a.DATA_DIR/'db.sqlite3';a.init_db()
  with a.db_connect() as c:
   c.execute('INSERT INTO users(id,username,password_hash,role,group_id,created_at) VALUES(?,?,?,?,?,?)',('d1','director',a.pwd_hash('StrongPassword2026'),'director',None,a.now()))
   c.execute('INSERT INTO groups(id,name,category,teacher,start_date,days,time,capacity,fee,status) VALUES(?,?,?,?,?,?,?,?,?,?)',('g1','Б-27','B тоифа','Тест','2026-10-12','Душ','10:00',20,3000000,'Фаол'))
  cls.srv=ThreadingHTTPServer(('127.0.0.1',0),a.Handler)
  cls.thread=threading.Thread(target=cls.srv.serve_forever,daemon=True);cls.thread.start()
  cls.url='http://127.0.0.1:'+str(cls.srv.server_port)
 @classmethod
 def tearDownClass(cls):
  cls.srv.shutdown();cls.srv.server_close();cls.thread.join(timeout=2);cls.tmp.cleanup()
 def test_login_then_download_pdf_without_new_popup(self):
  client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(CookieJar()))
  with self.assertRaises(urllib.error.HTTPError) as cm:
   client.open(self.url+'/api/students/'+'a'*32+'/contract.pdf')
  self.assertEqual(cm.exception.code,401)
  login=json.dumps({'username':'director','password':'StrongPassword2026','remember30':True}).encode()
  req=urllib.request.Request(self.url+'/api/login',data=login,headers={'Content-Type':'application/json'})
  with client.open(req) as response:
   csrf=json.load(response)['csrf']
  s={'name':'Алишер Ўқувчи','phone':'+998901234567','groupId':'g1','join':'2026-10-12','fee':3000000,'status':'Ўқимоқда','contractNo':'SH-2026-0001','contractDate':'2026-10-12'}
  req=urllib.request.Request(self.url+'/api/students',data=json.dumps(s,ensure_ascii=False).encode('utf-8'),headers={'Content-Type':'application/json','X-CSRF-Token':csrf},method='POST')
  with client.open(req) as resp:
   sid=json.load(resp)['id']
  with client.open(self.url+'/api/students/'+sid+'/contract.pdf') as resp:
   self.assertEqual(resp.status,200)
   self.assertEqual(resp.headers['Content-Type'],'application/pdf')
   self.assertIn('attachment;',resp.headers['Content-Disposition'])
   self.assertIn('no-store',resp.headers['Cache-Control'])
   pdf=resp.read()
   self.assertTrue(pdf.startswith(b'%PDF-'))
   self.assertGreater(len(pdf),1000)

if __name__=='__main__': unittest.main()
