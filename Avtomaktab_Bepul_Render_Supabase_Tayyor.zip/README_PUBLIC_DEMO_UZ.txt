IDIAL MASTER MAKTAB — ЛОГИНСИЗ ТАНИШУВ САҲИФАСИ

Сайт / — жамоат учун паролсиз, фақат танишув. Маълумотларни кўрмайди ва ўзгартирмайди.
Сайт /admin — директорнинг логин-паролли бошқаруви.
API авторизацияси ўзгартирилмаган: ҳақиқий маълумотлар ҳимояланган.

ЭСКИ RENDER СЕРВЕРИНИ ЯНГИЛАШ:
1. Ушбу ZIP файлни Avtomaktab_Bepul_Render_Supabase_Tayyor.zip номи билан GitHub репозиторийсининг илдиз папкасига юкланг. Олдинги бир хил номли архивни алмаштиринг.
2. Render build буйруғи: python -m zipfile -e Avtomaktab_Bepul_Render_Supabase_Tayyor.zip . && python -m pip install -r requirements.txt
3. Render Environment да PRIVATE_PRELAUNCH=0 бўлиши керак.
4. Сайт манзили https://avto-maktab-1o3m.onrender.com
5. Директор саҳифаси: https://avto-maktab-1o3m.onrender.com/admin

МУҲИМ: Render Free/SQLite доимий маълумот сақлаш учун ярамайди. Ҳақиқий ўқувчи ва тўловларни фақат PostgreSQL база ва захиралаш йўлга қўйилгандан кейин киритинг.
