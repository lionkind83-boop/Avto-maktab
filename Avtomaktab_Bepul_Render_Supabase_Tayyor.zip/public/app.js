
(()=>{'use strict';
let currentUser=null,csrf='',data={students:[],groups:[],payments:[],attendance:[]},usersCache=[],auditCache=[];
const PUBLIC_DEMO=document.body.dataset.publicDemo==='1';
const MENU=[['dashboard','Асосий','home'],['students','Ўқувчилар','users'],['groups','Гуруҳлар','layers'],['payments','Тўловлар','wallet'],['attendance','Давомат','calendar'],['reports','Ҳисоботлар','chart'],['settings','Созламалар','settings']];
const subtitles={dashboard:'IDIAL MASTER MAKTAB автомактаби фаолияти бир жойда',students:'Ўқувчилар рўйхати ва шартномалар',groups:'Ўқув гуруҳлари ва машғулотлар',payments:'Тушумлар ва қарздорлик назорати',attendance:'Дарсларга қатнашишни қайд этиш',reports:'Молиявий ва ўқув жараёни таҳлили',settings:'Маълумотларни сақлаш ва бошқариш'};
const SVG={home:'<path d="m3 10 9-7 9 7v10H3z"/><path d="M9 20v-7h6v7"/>',users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8a4 4 0 0 1 0 8m3 5v-2a4 4 0 0 0-3-3.87"/>',layers:'<path d="m12 2 9 5-9 5-9-5 9-5Zm-9 10 9 5 9-5M3 17l9 5 9-5"/>',wallet:'<rect x="2" y="5" width="20" height="15" rx="2"/><path d="M2 9h20M6 2h12"/>',calendar:'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M8 2v4m8-4v4M3 10h18M8 15l2 2 5-5"/>',chart:'<path d="M3 3v18h18M7 17v-5m5 5V7m5 10v-8"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.5 2.6-1.8-.7a8 8 0 0 1-2 .9l-.3 1.9h-3l-.3-1.9a8 8 0 0 1-2-.9l-1.8.7-1.5-2.6 1.4-1.1a8 8 0 0 1-.2-2l-1.4-1.1 1.5-2.6 1.8.7a8 8 0 0 1 2-.9L12 6h3l.3 1.9a8 8 0 0 1 2 .9l1.8-.7 1.5 2.6-1.4 1.1a8 8 0 0 1 .2 3.2"/>',edit:'<path d="M12 20h9M4 16l-1 5 5-1L20 8l-4-4z"/>',trash:'<path d="M3 6h18M8 6V4h8v2m3 0-1 15H6L5 6m5 4v7m4-7v7"/>',plus:'<path d="M12 5v14M5 12h14"/>',download:'<path d="M12 3v13m-5-5 5 5 5-5M4 19h16"/>',print:'<path d="M6 9V3h12v6M6 18H4V9h16v9h-2m-12-4h12v7H6z"/>',arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',check:'<path d="m5 12 5 5L20 7"/>',menu:'<path d="M4 6h16M4 12h16M4 18h16"/>'};
const ic=(key)=>`<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SVG[key]||SVG.home}</svg>`;
const esc=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>new Intl.NumberFormat('ru-RU',{maximumFractionDigits:0}).format(Math.round(Number(n)||0))+' сўм';
const shortMoney=n=>n>=1e6?(n/1e6).toFixed(n%1e6===0?0:1)+' млн':n>=1000?Math.round(n/1000)+' минг':String(Math.round(n));
const localDate=(date)=>dateForEntry(date||iso(new Date()));
const iso=(d)=>{let x=new Date(d);return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`};
const shift=(date,days)=>{let d=new Date(date+'T12:00:00');d.setDate(d.getDate()+days);return iso(d)};
const monthStart=(d=iso(new Date()))=>d.slice(0,7)+'-01';
const monthShift=(m,off)=>{let d=new Date(m+'-15T12:00:00');d.setMonth(d.getMonth()+off);return iso(d).slice(0,7)};
const monthName=(m)=>new Intl.DateTimeFormat('uz-Cyrl-UZ',{month:'short'}).format(new Date(m+'-15T12:00:00'));
const id=()=>('i'+Math.random().toString(36).slice(2,9)+Date.now().toString(36));
const max=(v,l)=>Math.max(0,Math.min(l,v));

// All editable dates accept 01.01.2026 or an ISO date, and are stored as YYYY-MM-DD.
function dateForEntry(value){
 const v=String(value||'');const m=v.match(/^(\d{4})-(\d{2})-(\d{2})$/);
 return m?`${m[3]}.${m[2]}.${m[1]}`:v;
}
function parseEditableDate(value){
 const v=String(value||'').trim();if(!v)return {ok:true,iso:''};
 let y,m,d,r;
 if((r=/^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(v))){y=+r[1];m=+r[2];d=+r[3]}
 else if((r=/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})$/.exec(v))){d=+r[1];m=+r[2];y=+r[3]}
 else return {ok:false,iso:''};
 const x=new Date(Date.UTC(y,m-1,d));
 if(y<1900||y>2100||x.getUTCFullYear()!==y||x.getUTCMonth()!==m-1||x.getUTCDate()!==d)return {ok:false,iso:''};
 return {ok:true,iso:`${String(y).padStart(4,'0')}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`};
}
function dateEntry(name,value='',required=false,inForm=false){
 const initial=String(value||'');const id=inForm?'f_'+name:name;
 return `<div class="date-entry"><input class="input date-entry-text" id="${id}" ${inForm?`name="${name}" data-date-form="1"`: 'data-date-filter="1"'} type="text" inputmode="numeric" autocomplete="off" maxlength="10" placeholder="КК.ОО.ЙЙЙЙ" value="${esc(dateForEntry(initial))}" ${required?'required':''} aria-label="Санани кун.ой.йил шаклида киритинг"><input type="date" class="date-entry-picker" data-date-target="${id}" aria-label="${esc(name)}: календардан танлаш" value="${esc(initial)}" title="Календардан танлаш"></div>`;
}
function applyEditedDate(input){
 const parsed=parseEditableDate(input.value);
 if(!parsed.ok){input.setCustomValidity('Санани 01.01.2026 шаклида киритинг.');input.reportValidity();return null}
 input.setCustomValidity('');input.value=dateForEntry(parsed.iso);return parsed.iso;
}

let page='dashboard';let studentFilter={q:'',group:'',status:''},paymentFilter={q:'',method:''};let attGroup='',attDate=iso(new Date()),attDraft={};let reportFrom=monthStart(),reportTo=iso(new Date());let modal='';
function isValid(d){return d&&Array.isArray(d.students)&&Array.isArray(d.groups)&&Array.isArray(d.payments)&&Array.isArray(d.attendance)}
function toast(t,err=false){let box=document.getElementById('toastHost');box.innerHTML=`<div class="toast ${err?'error':''}" role="status">${esc(t)}</div>`;clearTimeout(toast.t);toast.t=setTimeout(()=>box.innerHTML='',3500)}


const allowed=(p)=>!!currentUser?.permissions?.includes(p);
const roleName={director:'Директор',accountant:'Бухгалтер',cashier:'Кассир',teacher:'Ўқитувчи'};
async function api(path,method='GET',payload=undefined){
 const opts={method,credentials:'same-origin',headers:{}};
 if(payload!==undefined){opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(payload)}
 if(method!=='GET')opts.headers['X-CSRF-Token']=csrf;
 let r;
 try{r=await fetch(path,opts)}catch(e){throw Error('Сервер билан алоқа узилди. Интернетни текширинг.')}
 let x=await r.json().catch(()=>({error:'Сервер жавоби ўқилмади.'}));
 if(r.status===401&&path!=='/api/login'){showLogin();throw Error('Сессия тугаган. Қайта киринг.')}
 if(!r.ok)throw Error(x.error||'Серверда хатолик.');return x;
}
async function loadState(){data=await api('/api/state');if(!group(attGroup))attGroup=data.groups[0]?.id||'';renderNav();render()}
async function mutate(path,method,payload,message){try{await api(path,method,payload);await loadState();closeModal();toast(message);return true}catch(e){toast(e.message,true);return false}}
function showLogin(){closeModal();currentUser=null;csrf='';document.getElementById('loginOverlay').hidden=false;document.getElementById('mainLayout').hidden=true;document.getElementById('loginPassword').value='';}
async function enterApp(){document.getElementById('loginOverlay').hidden=true;document.getElementById('mainLayout').hidden=false;
 document.getElementById('loginNameLabel').textContent=PUBLIC_DEMO?'Меҳмон · Танишув':currentUser.username+' · '+(roleName[currentUser.role]||'');
 document.getElementById('loginAvatar').textContent=currentUser.username.slice(0,2).toUpperCase();
 document.getElementById('sidebarRole').textContent=PUBLIC_DEMO?'● ПАРОЛСИЗ ТАНИШУВ':roleName[currentUser.role]+' · ОНЛАЙН';
 document.getElementById('dateChip').textContent=localDate(iso(new Date()));
 document.getElementById('topAddStudent').style.display=allowed('students_write')?'':'none';
 page=currentUser.role==='teacher'?'attendance':'dashboard';if(PUBLIC_DEMO){renderNav();render();setPage('dashboard')}else{await loadState();setPage(page)}
}
async function init(){if(PUBLIC_DEMO){currentUser={username:'Меҳмон',role:'director',permissions:['payments_read','reports']};csrf='';return enterApp()}try{let result=await api('/api/me');currentUser=result.user;csrf=result.csrf;await enterApp()}catch(e){showLogin()}}
const group=(id)=>data.groups.find(g=>g.id===id);
const student=(id)=>data.students.find(s=>s.id===id);
const paid=(studentId)=>data.payments.filter(p=>p.studentId===studentId).reduce((a,p)=>a+Number(p.amount),0);
const debt=(s)=>Math.max(0,Number(s.fee||0)-paid(s.id));
const debtTotal=()=>data.students.reduce((a,s)=>a+debt(s),0);
const getGroupStudents=(gid)=>data.students.filter(s=>s.groupId===gid);
const allPaid=()=>data.payments.reduce((a,p)=>a+Number(p.amount),0);
const thisMonth=()=>data.payments.filter(p=>p.date.slice(0,7)===iso(new Date()).slice(0,7)).reduce((a,p)=>a+Number(p.amount),0);
function statusBadge(s){return `<span class="badge ${s==='Ўқимоқда'||s==='Фаол'||s==='Келди'?'green':s==='Тугатган'?'blue':s==='Келмади'||s==='Тўхтатилган'?'red':'orange'}">${esc(s)}</span>`}
function statCard(label,value,hint,icon,color=''){return `<article class="card kpi ${color}"><div class="label">${label}</div><div class="ico">${ic(icon)}</div><div class="value ${String(value).includes('сўм')?'amount':''}">${value}</div><div class="hint">${hint}</div></article>`}
function panel(title,sub,content,extra=''){return `<section class="panel"><div class="panelhead"><div><h2>${title}</h2>${sub?`<p>${sub}</p>`:''}</div>${extra}</div>${content}</section>`}
function noData(msg='Маълумот топилмади'){return `<div class="empty">◎<b>${msg}</b><span>Фильтрни ўзгартиринг ёки янги маълумот қўшинг.</span></div>`}
function allowedPage(p){return !(p==='payments'&&!allowed('payments_read')||p==='reports'&&!allowed('reports')||p==='dashboard'&&currentUser?.role==='teacher'||p==='students'&&currentUser?.role==='teacher'||p==='groups'&&currentUser?.role==='teacher'||p==='attendance'&&currentUser?.role==='cashier')}
function renderNav(){document.getElementById('navigation').innerHTML=MENU.filter(v=>allowedPage(v[0])).map(([p,t,i])=>`<button data-page="${p}" class="nav-item ${page===p?'active':''}">${ic(i)} ${t}</button>`).join('')}
function setPage(p){if(!allowedPage(p))p=currentUser?.role==='teacher'?'attendance':'dashboard';page=p;document.getElementById('pageTitle').textContent=MENU.find(v=>v[0]===p)?.[1]||'Асосий';document.getElementById('pageSubtitle').textContent=subtitles[p]||'';renderNav();render();closeMenu();window.scrollTo({top:0,behavior:'instant'});if(p==='settings'&&allowed('users'))loadSettings()}
function render(){let html={dashboard:renderDashboard,students:renderStudents,groups:renderGroups,payments:renderPayments,attendance:renderAttendance,reports:renderReports,settings:renderSettings}[page]();document.getElementById('appContent').innerHTML=html;document.querySelectorAll('[data-action]').forEach(el=>{const a=el.dataset.action;if((['add-student','edit-student','del-student','view-student-contract'].includes(a)&&!allowed('students_write'))||(['add-group','edit-group','del-group'].includes(a)&&!allowed('groups_write'))||(['add-payment'].includes(a)&&!allowed('payments_write'))||(['del-payment'].includes(a)&&!allowed('payments_void'))||(['attendance-select','save-attendance'].includes(a)&&!allowed('attendance_write'))||(['backup'].includes(a)&&!allowed('backup'))){el.style.display='none'}})}
function renderDashboard(){const studentCount=data.students.filter(s=>s.status==='Ўқимоқда').length;const month=iso(new Date()).slice(0,7);const months=Array.from({length:6},(_,i)=>monthShift(month,i-5));const montTotals=months.map(m=>data.payments.filter(p=>p.date.slice(0,7)===m).reduce((a,p)=>a+Number(p.amount),0));const top=Math.max(1,...montTotals);
 const recent=[...data.payments].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);const debtors=[...data.students].filter(s=>debt(s)>0).sort((a,b)=>debt(b)-debt(a)).slice(0,5);
 const series=`<div class="bars">${months.map((m,i)=>{const h=Math.max(4,Math.round(montTotals[i]/top*170));return `<div class="bar-group"><div class="bar-value" style="bottom:${h+7}px">${shortMoney(montTotals[i])}</div><div class="bar" style="height:${h}px"></div><span>${esc(monthName(m))}</span></div>`}).join('')}</div><div class="chart-bottom"><span>Охирги 6 ой бўйича тўловлар</span><b>${money(montTotals.reduce((a,b)=>a+b,0))}</b></div>`;
 const latest=recent.length?recent.map(p=>{let s=student(p.studentId);return `<div class="minirow"><span class="bubble">${esc((s?.name||'?').split(' ').map(n=>n[0]).slice(0,2).join(''))}</span><div><div class="mininame">${esc(s?.name||'Ўчирилган ўқувчи')}</div><div class="minisub">${localDate(p.date)} · ${esc(p.method)}</div></div><div class="miniend text-green">+${money(p.amount)}</div></div>`}).join(''):noData();
 const debtRows=debtors.length?debtors.map(s=>`<div class="minirow"><span class="bubble">${esc(s.name[0])}</span><div><div class="mininame">${esc(s.name)}</div><div class="minisub">${esc(group(s.groupId)?.name||'Гуруҳсиз')}</div></div><div class="miniend text-danger">${money(debt(s))}</div></div>`).join(''):noData('Қарздор ўқувчи йўқ');
 const summaries=data.groups.map(g=>{const n=getGroupStudents(g.id).length;const pct=max(n/g.capacity*100,100);return `<div class="minirow"><span class="bubble">${esc(g.name[0])}</span><div style="flex:1"><div class="mininame">${esc(g.name)} <span class="subtle" style="display:inline">· ${esc(g.teacher)}</span></div><div class="progress" style="width:100%;max-width:265px"><div class="fill" style="width:${pct}%"></div></div></div><div class="miniend">${n}/${g.capacity}</div></div>`}).join('');
 return `<div class="kpis">${statCard('Фаол ўқувчилар',studentCount,'Жами: '+data.students.length+' нафар','users')}${statCard('Фаол гуруҳлар',data.groups.filter(g=>g.status==='Фаол').length,'Жами: '+data.groups.length+' та гуруҳ','layers','yellow')}${statCard('Шу ойги тушум',money(thisMonth()),'Жорий ой учун','wallet','green')}${statCard('Жами қарздорлик',money(debtTotal()),'Шартнома қолдиғи','chart','red')}</div><div class="columns">${panel('Тўловлар динамикаси','Ойлар кесимида тушум',series,'<span class="pill">6 ой</span>')}${panel('Охирги тўловлар','Сўнгги киримлар',latest)}</div><div class="columns">${panel('Гуруҳлар бандлиги','Ҳозирги ўқувчилар сони',summaries||noData())}${panel('Энг катта қарздорликлар','Тўланмаган шартнома суммаси',debtRows)}</div>`;
}
function renderStudents(){let opts=`<option value="">Барча гуруҳлар</option>`+data.groups.map(g=>`<option value="${g.id}" ${studentFilter.group===g.id?'selected':''}>${esc(g.name)}</option>`).join('');const filtered=filteredStudents();const rows=filtered.length?filtered.map((s,i)=>{const p=paid(s.id),d=debt(s),ratio=s.fee?max(p/s.fee*100,100):0;return `<tr><td>${i+1}</td><td><span class="strong">${esc(s.name)}</span><span class="subtle">${esc(s.phone)}</span></td><td>${esc(group(s.groupId)?.name||'—')}</td><td><span class="strong">${esc(s.contractNo||'Киритилмаган')}</span><span class="subtle">${s.contractDate?contractDateText(s.contractDate):'Сана киритилмаган'}</span></td><td>${money(s.fee)}</td><td><span class="strong text-green">${money(p)}</span><div class="progress"><div class="fill" style="width:${ratio}%"></div></div></td><td class="${d?'text-danger':'text-green'}">${money(d)}</td><td>${statusBadge(s.status)}</td><td><div class="actions"><button class="btn" title="Шартнома реквизитлари" data-action="view-student-contract" data-id="${s.id}">Реквизитлар</button><button class="btn" data-action="contract-pdf" data-id="${s.id}">📄 PDF</button><button class="iconbtn" title="Таҳрирлаш" data-action="edit-student" data-id="${s.id}">${ic('edit')}</button><button class="iconbtn" title="Ўчириш" data-action="del-student" data-id="${s.id}">${ic('trash')}</button></div></td></tr>`}).join(''):'';
 return `<div class="toolbar"><div class="tool-left"><input id="studentSearch" class="input search" placeholder="Исм, телефон ёки шартнома рақами орқали қидириш" value="${esc(studentFilter.q)}"><select id="studentGroupFilter" class="select">${opts}</select><select id="studentStatusFilter" class="select"><option value="">Барча ҳолатлар</option>${['Ўқимоқда','Тугатган','Тўхтатилган'].map(t=>`<option ${studentFilter.status===t?'selected':''}>${t}</option>`).join('')}</select></div><div class="tool-right"><span class="pill">${filtered.length} та ўқувчи</span><button class="btn" data-action="edit-organization">Ташкилот реквизитлари</button><button class="btn primary" data-action="add-student">${ic('plus')} Ўқувчи қўшиш</button></div></div><div class="panel" style="padding:0">${filtered.length?`<div class="tablewrap"><table><thead><tr><th>№</th><th>Ф.И.Ш. / ТЕЛЕФОН</th><th>ГУРУҲ</th><th>ШАРТНОМА РАҚАМИ / САНАСИ</th><th>СУММА</th><th>ТЎЛАНГАН</th><th>ҚАРЗ</th><th>ҲОЛАТ</th><th>АМАЛЛАР</th></tr></thead><tbody>${rows}</tbody></table></div>`:noData()}</div>`;
}

function filteredStudents(){let q=studentFilter.q.trim().toLocaleLowerCase();return data.students.filter(s=>(!q||s.name.toLocaleLowerCase().includes(q)||s.phone.includes(q)||String(s.contractNo||'').toLocaleLowerCase().includes(q))&&(!studentFilter.group||s.groupId===studentFilter.group)&&(!studentFilter.status||s.status===studentFilter.status))}
function renderGroups(){let groups=data.groups.map(g=>{let students=getGroupStudents(g.id),pct=max(students.length/g.capacity*100,100);return `<article class="card group-card"><div class="group-header"><div><h3>${esc(g.name)}</h3><div class="groupmeta">${esc(g.category)}</div></div>${statusBadge(g.status)}</div><div class="group-details"><div><div class="metric-label">ЎҚИТУВЧИ</div><div class="metric-data">${esc(g.teacher)}</div></div><div><div class="metric-label">БОШЛАНГАН САНА</div><div class="metric-data">${localDate(g.start)}</div></div><div><div class="metric-label">ДАРС КУНЛАРИ</div><div class="metric-data">${esc(g.days)}</div></div><div><div class="metric-label">ДАРС ВАҚТИ</div><div class="metric-data">${esc(g.time)}</div></div><div><div class="metric-label">ШАРТНОМА НАРХИ</div><div class="metric-data">${money(g.fee)}</div></div><div><div class="metric-label">ЎҚУВЧИЛАР</div><div class="metric-data">${students.length}/${g.capacity}</div></div></div><div class="progress" style="width:100%"><div class="fill" style="width:${pct}%"></div></div><div class="group-footer"><span class="hinttext">${Math.round(pct)}% тўлган</span><div class="actions"><button class="btn" data-action="view-group" data-id="${g.id}">Ўқувчилар</button><button class="iconbtn" title="Таҳрирлаш" data-action="edit-group" data-id="${g.id}">${ic('edit')}</button><button class="iconbtn" title="Ўчириш" data-action="del-group" data-id="${g.id}">${ic('trash')}</button></div></div></article>`}).join('');return `<div class="toolbar"><div class="tool-left"><span class="pill">Жами: ${data.groups.length} та гуруҳ</span></div><button class="btn primary" data-action="add-group">${ic('plus')} Гуруҳ қўшиш</button></div><div class="groups">${groups||noData('Ҳали гуруҳ йўқ')}</div>`}
function filteredPayments(){let q=paymentFilter.q.toLocaleLowerCase();return [...data.payments].filter(p=>{let s=student(p.studentId);return (!paymentFilter.method||p.method===paymentFilter.method)&&(!q||s?.name.toLocaleLowerCase().includes(q)||s?.phone.includes(q))}).sort((a,b)=>b.date.localeCompare(a.date))}
function renderPayments(){let records=filteredPayments();let total=records.reduce((a,p)=>a+Number(p.amount),0);const rows=records.map((p,i)=>{let s=student(p.studentId);return `<tr><td>${i+1}</td><td>${localDate(p.date)}</td><td><span class="strong">${esc(s?.name||'Номаълум')}</span><span class="subtle">${esc(group(s?.groupId)?.name||'—')}</span></td><td class="strong text-green">${money(p.amount)}</td><td>${esc(p.method)}</td><td>${esc(p.note||'—')}</td><td><button class="iconbtn" data-action="del-payment" data-id="${p.id}" title="Тўловни бекор қилиш">${ic('trash')}</button></td></tr>`}).join('');return `<div class="statline"><div class="statpill"><small>Барча тушум</small><b>${money(allPaid())}</b></div><div class="statpill"><small>Шу ойда</small><b>${money(thisMonth())}</b></div><div class="statpill"><small>Жами қарздорлик</small><b class="text-danger">${money(debtTotal())}</b></div></div><div class="toolbar"><div class="tool-left"><input id="paymentSearch" class="input search" placeholder="Ўқувчи қидириш" value="${esc(paymentFilter.q)}"><select id="paymentMethodFilter" class="select"><option value="">Барча тўлов турлари</option>${['Нақд','Карта','Банк'].map(m=>`<option ${paymentFilter.method===m?'selected':''}>${m}</option>`).join('')}</select></div><div class="tool-right"><span class="pill">Танланган: ${money(total)}</span><button class="btn primary" data-action="add-payment">${ic('plus')} Тўлов киритиш</button></div></div><div class="panel" style="padding:0">${records.length?`<div class="tablewrap"><table><thead><tr><th>№</th><th>САНА</th><th>ЎҚУВЧИ / ГУРУҲ</th><th>СУММА</th><th>ТЎЛОВ УСУЛИ</th><th>ИЗОҲ</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`:noData('Тўловлар топилмади')}</div>`}
function attendanceSaved(gid,date,sid){return data.attendance.find(a=>a.groupId===gid&&a.date===date&&a.studentId===sid)?.status||''}
function renderAttendance(){if(!group(attGroup))attGroup=data.groups[0]?.id||'';const list=getGroupStudents(attGroup);let cnt={Келди:0,Келмади:0,Сабабли:0,Белгиланмаган:0};const rows=list.map((s,i)=>{const v=attDraft[s.id]||attendanceSaved(attGroup,attDate,s.id);cnt[v||'Белгиланмаган']++;return `<tr><td>${i+1}</td><td><span class="strong">${esc(s.name)}</span><span class="subtle">${esc(s.phone)}</span></td><td><div class="att-controls">${['Келди','Келмади','Сабабли'].map((state,index)=>`<button class="att-btn ${v===state?'selected '+['yes','no','excused'][index]:''}" data-action="attendance-select" data-id="${s.id}" data-status="${state}">${state}</button>`).join('')}</div></td><td>${statusBadge(v||'Белгиланмаган')}</td></tr>`}).join('');
 return `<div class="panel" style="margin-bottom:19px"><div class="filters-row"><div class="field"><label>Гуруҳ</label><select id="attGroup" class="select">${data.groups.map(g=>`<option value="${g.id}" ${attGroup===g.id?'selected':''}>${esc(g.name)}</option>`).join('')}</select></div><div class="field"><label>Дарс санаси</label>${dateEntry('attDate',attDate,false,false)}</div><button class="btn primary" data-action="save-attendance">${ic('check')} Давоматни сақлаш</button></div></div><div class="statline"><div class="statpill"><small>Келганлар</small><b class="text-green">${cnt.Келди}</b></div><div class="statpill"><small>Келмаганлар</small><b class="text-danger">${cnt.Келмади}</b></div><div class="statpill"><small>Сабабли</small><b>${cnt.Сабабли}</b></div><div class="statpill"><small>Белгиланмаган</small><b>${cnt.Белгиланмаган}</b></div></div><section class="panel" style="padding:0"><div class="panelhead" style="padding:20px 21px 0"><div><h2>${esc(group(attGroup)?.name||'Гуруҳ танланмаган')} — давомат</h2><p>Ҳар бир ўқувчи учун қатнашиш ҳолатини белгиланг</p></div></div>${list.length?`<div class="tablewrap"><table><thead><tr><th>№</th><th>ЎҚУВЧИ</th><th>ДАВОМАТ БЕЛГИСИ</th><th>ҲОЛАТ</th></tr></thead><tbody>${rows}</tbody></table></div>`:noData('Гуруҳда ўқувчи йўқ')}</section><p class="hinttext">⚠️ Белгиларни танлагандан кейин «Давоматни сақлаш» тугмасини босинг. Белгиланмаган ўқувчилар ўзгаришсиз қолади.</p>`;
}
function periodPayments(){return data.payments.filter(p=>p.date>=reportFrom&&p.date<=reportTo)}
function renderReports(){const records=periodPayments();const total=records.reduce((a,p)=>a+Number(p.amount),0);const net=records.filter(p=>p.method==='Нақд').reduce((a,p)=>a+Number(p.amount),0);let attend=data.attendance.filter(a=>a.date>=reportFrom&&a.date<=reportTo);const attended=attend.filter(a=>a.status==='Келди').length;const pct=attend.length?Math.round(attended/attend.length*100):0;
 const rows=data.groups.map(g=>{let s=getGroupStudents(g.id),p=records.filter(p=>s.some(x=>x.id===p.studentId)).reduce((a,p)=>a+Number(p.amount),0),d=s.reduce((a,x)=>a+debt(x),0);return `<tr><td class="strong">${esc(g.name)}</td><td>${esc(g.category)}</td><td>${s.length}</td><td class="text-green">${money(p)}</td><td class="text-danger">${money(d)}</td><td>${esc(g.teacher)}</td></tr>`}).join('');
 return `<div class="report-print-area"><div class="print-header"><h1>IDIAL MASTER MAKTAB AVTOMAKTAB — ҲИСОБОТ</h1><p>${localDate(reportFrom)} — ${localDate(reportTo)}</p></div><div class="toolbar"><div class="tool-left"><div class="field"><label>Давр боши</label>${dateEntry('reportFrom',reportFrom,false,false)}</div><div class="field"><label>Давр охири</label>${dateEntry('reportTo',reportTo,false,false)}</div></div><div class="tool-right"><button class="btn" data-action="csv-report">${ic('download')} Excel (CSV)</button><button class="btn primary" data-action="print">${ic('print')} Чоп этиш / PDF</button></div></div><div class="report-grid"><div class="report-summary"><div class="metric-label">ДАВР ТУШУМИ</div><div class="v text-green">${money(total)}</div><span class="hinttext">${records.length} та тўлов</span></div><div class="report-summary"><div class="metric-label">НАҚД ТУШУМ</div><div class="v">${money(net)}</div><span class="hinttext">Бошқа усуллар: ${money(total-net)}</span></div><div class="report-summary"><div class="metric-label">ДАВОМАТ</div><div class="v">${pct}%</div><span class="hinttext">${attended}/${attend.length} та қатнашиш белгиси</span></div></div><div class="report-grid" style="grid-template-columns:repeat(2,minmax(0,1fr))"><div class="report-summary"><div class="metric-label">ЖАМИ ШАРТНОМА ҚАРЗИ (ЖОРИЙ)</div><div class="v text-danger">${money(debtTotal())}</div><span class="hinttext">Қарздорлик сана диапазонига эмас, ҳозирги ҳолатга тегишли</span></div><div class="report-summary"><div class="metric-label">БАРЧА ЎҚУВЧИЛАР</div><div class="v">${data.students.length} нафар</div><span class="hinttext">${data.students.filter(s=>s.status==='Ўқимоқда').length} нафари фаол</span></div></div><div class="panel"><div class="panelhead"><div><h2>Гуруҳлар бўйича ҳисобот</h2><p>Тушум — танланган давр, қарздорлик — жорий қолдиқ</p></div></div>${data.groups.length?`<div class="tablewrap"><table><thead><tr><th>ГУРУҲ</th><th>ТОИФА</th><th>ЎҚУВЧИ</th><th>ДАВР ТУШУМИ</th><th>ҚАРЗДОРЛИК</th><th>ЎҚИТУВЧИ</th></tr></thead><tbody>${rows}</tbody></table></div>`:noData('Гуруҳлар йўқ')}</div><div class="panel" style="margin-top:20px"><div class="panelhead"><div><h2>Тўловлар реестри</h2><p>${localDate(reportFrom)} — ${localDate(reportTo)}</p></div></div><div class="tablewrap"><table><thead><tr><th>САНА</th><th>ЎҚУВЧИ</th><th>ГУРУҲ</th><th>ТЎЛОВ</th><th>УСУЛ</th></tr></thead><tbody>${[...records].sort((a,b)=>b.date.localeCompare(a.date)).map(p=>{const s=student(p.studentId);return `<tr><td>${localDate(p.date)}</td><td>${esc(s?.name||'—')}</td><td>${esc(group(s?.groupId)?.name||'—')}</td><td>${money(p.amount)}</td><td>${esc(p.method)}</td></tr>`}).join('')||'<tr><td colspan="5">Маълумот йўқ</td></tr>'}</tbody></table></div></div></div>`;
}
function closeMenu(){document.getElementById('sidebar').classList.remove('open');document.getElementById('screenDim').classList.remove('open')}
function showModal(title,fields,submitLabel,onSubmit){modal=title;document.getElementById('modalHost').innerHTML=`<div class="modal-backdrop" id="modalBackdrop"><div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="modal-header"><h3>${esc(title)}</h3><button class="close" type="button" data-action="close-modal" aria-label="Ёпиш">×</button></div><form id="modalForm"><div class="modal-body"><div class="form-grid">${fields}</div></div><div class="modal-footer"><button class="btn" type="button" data-action="close-modal">Бекор қилиш</button><button type="submit" class="btn primary">${esc(submitLabel)}</button></div></form></div></div>`;document.getElementById('modalForm').addEventListener('submit',async e=>{e.preventDefault();const form=e.currentTarget;if(form.dataset.busy)return;const btn=form.querySelector('[type=submit]');form.dataset.busy='1';btn.disabled=true;try{const values=Object.fromEntries(new FormData(form).entries());let dateInvalid=false;
 for(const el of form.querySelectorAll('[data-date-form]')){
  const parsed=applyEditedDate(el);if(parsed===null){dateInvalid=true;break}values[el.name]=parsed;
 }
 if(!dateInvalid)await onSubmit(values)}finally{btn.disabled=false;delete form.dataset.busy}});document.querySelector('#modalForm input,#modalForm select')?.focus()}
function closeModal(){document.getElementById('modalHost').innerHTML='';modal=''}
function field(name,label,value='',type='text',required=true,opts=null){if(type==='date')return `<div class="field"><label for="f_${name}">${esc(label)}</label>${dateEntry(name,value,required,true)}</div>`;return `<div class="field"><label for="f_${name}">${esc(label)}</label>${opts?`<select class="select" id="f_${name}" name="${name}" ${required?'required':''}>${opts.map(([v,text])=>`<option value="${esc(v)}" ${String(v)===String(value)?'selected':''}>${esc(text)}</option>`).join('')}</select>`:`<input class="input" id="f_${name}" type="${type}" name="${name}" value="${esc(value)}" ${type==='number'?'min="0" step="1"':''} ${required?'required':''}>`}</div>`}
function csv(rows,filename){const safe=x=>{let text=String(x??'');if(/^[\t\r\n ]*[=+@-]/.test(text)&&!/^[-]?\d+(?:\.\d+)?$/.test(text))text="'"+text;return '"'+text.replace(/"/g,'""')+'"'};let content='\ufeff'+rows.map(r=>r.map(safe).join(';')).join('\r\n');download(filename,new Blob([content],{type:'text/csv;charset=utf-8'}))}
function download(name,blob){let a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function exportCSV(){let pays=[...periodPayments()].sort((a,b)=>a.date.localeCompare(b.date));const rows=[['IDIAL MASTER MAKTAB AVTOMAKTAB - ТЎЛОВЛАР РЕЕСТРИ'],['Давр',localDate(reportFrom),localDate(reportTo)],[],['Сана','Ўқувчи','Гуруҳ','Тўлов суммаси (сўм)','Тўлов усули','Изоҳ'],...pays.map(p=>{let s=student(p.studentId);return[localDate(p.date),s?.name||'',group(s?.groupId)?.name||'',p.amount,p.method,p.note||'']}),[],['ЖАМИ ТУШУМ','','',pays.reduce((a,p)=>a+Number(p.amount),0)],[],['ГУРУҲЛАР БЎЙИЧА ҲИСОБОТ'],['Гуруҳ','Тоифа','Ўқувчилар','Давр тушуми','Жорий қарз'],...data.groups.map(g=>{let s=getGroupStudents(g.id);return[g.name,g.category,s.length,pays.filter(p=>s.some(x=>x.id===p.studentId)).reduce((a,p)=>a+p.amount,0),s.reduce((a,x)=>a+debt(x),0)]})];csv(rows,`idial_master_maktab_hisobot_${reportFrom}_${reportTo}.csv`)}


const contractDateText=date=>date&&/^\d{4}-\d{2}-\d{2}$/.test(date)?date.slice(8,10)+'.'+date.slice(5,7)+'.'+date.slice(0,4):'—';
function contractNumberSuggestion(){
 const yr=new Date().getFullYear();let maxNo=0;
 data.students.forEach(s=>{const m=String(s.contractNo||'').match(new RegExp('^SH-'+yr+'-(\\d+)$','i'));if(m)maxNo=Math.max(maxNo,Number(m[1]))});
 return `SH-${yr}-${String(maxNo+1).padStart(4,'0')}`;
}
function contractSection(title,description,fields){return `<div class="form-section"><h4>${esc(title)}</h4><p>${esc(description)}</p></div>${fields}`}

function showStudentContract(sid){
 if(!allowed('students_write'))return;
 const s=student(sid);if(!s)return;
 const rows=[['Шартнома №',s.contractNo],['Шартнома санаси',s.contractDate?contractDateText(s.contractDate):''],['Ўқувчи Ф.И.Ш.',s.name],['Туғилган сана',s.birthDate?contractDateText(s.birthDate):''],['Паспорт / ID-карта',s.passport],['ЖШШИР',s.pinfl],['Яшаш манзили',s.address],['Телефон',s.phone],['Тўловчи (вакил)',s.payerName],['Тўловчи телефони',s.payerPhone],['Ўқув гуруҳи',group(s.groupId)?.name],['Тоифа',group(s.groupId)?.category],['Ўқиш бошланиши',s.courseStart?contractDateText(s.courseStart):''],['Ўқиш тугаши',s.courseEnd?contractDateText(s.courseEnd):''],['Шартнома суммаси',money(s.fee)],['Тўлов муддати',s.paymentDue?contractDateText(s.paymentDue):''],['Тўлов тартиби',s.paymentTerms],['Қўшимча изоҳ',s.contractNote]];
 const details=rows.map(([label,value])=>`<div class="contract-detail"><span>${esc(label)}</span><strong>${esc(value||'—')}</strong></div>`).join('');
 document.getElementById('modalHost').innerHTML=`<div class="modal-backdrop" id="modalBackdrop"><div class="modal contract-modal" role="dialog" aria-modal="true" aria-label="Шартнома реквизитлари"><div class="modal-header"><h3>Шартнома реквизитлари</h3><button class="close" type="button" data-action="close-modal" aria-label="Ёпиш">×</button></div><div class="modal-body"><div class="contract-details">${details}</div><p class="hinttext">Юкланган Word намунасига мос тўлиқ шартнома ва икки илова PDFда чиқади. Биринчи саҳифада паспорт ёки ЖШШИРни ошкор қилмайдиган QR идентификация коди бор.</p></div><div class="modal-footer"><button class="btn" data-action="close-modal">Ёпиш</button><button class="btn primary" data-action="edit-student" data-id="${s.id}">Таҳрирлаш</button><button class="btn" data-action="contract-pdf" data-id="${s.id}">PDF сақлаш</button></div></div></div>`;
}
// Schedule and practice rows are editable and are stored with each student's record.
function extraRows(raw,limit){try{const a=typeof raw==='string'?JSON.parse(raw||'[]'):raw;return Array.isArray(a)?a.slice(0,limit):[]}catch(e){return []}}
function paymentScheduleFields(student){
 const rows=extraRows(student.paymentScheduleJson,4);
 return `<details class="contract-extra"><summary><b>1-илова: Тўлов графиги (4 босқич)</b></summary><p class="hinttext">Муддат, сумма ва изоҳларни тўлдиринг. Саналар: 01.01.2026</p><div class="form-grid">`+
 Array.from({length:4},(_,i)=>{const r=rows[i]||{};const n=i+1;return `<div class="form-section"><h4>${n}-тўлов</h4></div>`+
 field('payDate'+n,'Тўлов санаси',r.date||'','date',false)+field('payAmount'+n,'Сумма (сўм)',r.amount||'','number',false)+field('payNote'+n,'Изоҳ',r.note||'','text',false)}).join('')+'</div></details>';
}
function practicalLogFields(student){
 const rows=extraRows(student.practiceLogJson,12);
 return `<details class="contract-extra"><summary><b>2-илова: Амалий машғулотлар ҳисоби (12 қатор)</b></summary><div class="form-grid">`+
 Array.from({length:12},(_,i)=>{const r=rows[i]||{},n=i+1;return `<div class="form-section"><h4>${n}-машғулот</h4></div>`+
 field('lessonDate'+n,'Сана',r.date||'','date',false)+field('lessonHours'+n,'Соат',r.hours||'','text',false)+field('lessonTopic'+n,'Мавзу ёки йўналиш',r.topic||'','text',false)+field('lessonInstructor'+n,'Йўриқчи',r.instructor||'','text',false)}).join('')+'</div></details>';
}
function serializeContractExtras(v){
 const pay=Array.from({length:4},(_,i)=>{const n=i+1;return {date:v['payDate'+n]||'',amount:v['payAmount'+n]||'',note:v['payNote'+n]||''}}).filter(r=>r.date||r.amount||r.note);
 const lessons=Array.from({length:12},(_,i)=>{const n=i+1;return {date:v['lessonDate'+n]||'',hours:v['lessonHours'+n]||'',topic:v['lessonTopic'+n]||'',instructor:v['lessonInstructor'+n]||''}}).filter(r=>r.date||r.hours||r.topic||r.instructor);
 v.paymentScheduleJson=JSON.stringify(pay);v.practiceLogJson=JSON.stringify(lessons);return v;
}
async function editOrganization(){
 if(!allowed('students_write'))return;
 try{
 const response=await api('/api/organization');const org=response.organization||{};
 const fields=contractSection('Ижрочи — автомактаб','Ушбу реквизитлар барча ўқувчиларнинг шартнома PDFларида ишлатилади.',
 field('name','Автомактабнинг юридик номи',org.name||'IDIAL MASTER MAKTAB')+
 field('inn','СТИР',org.inn||'','text',false)+field('license','Лицензия / рухсат реквизитлари',org.license||'','text',false)+
 field('director','Директор Ф.И.Ш.',org.director||'','text',false)+field('city','Шаҳар / туман',org.city||'','text',false)+
 field('address','Юридик манзил',org.address||'','text',false)+field('bank','Банк номи',org.bank||'','text',false)+
 field('account','Ҳисобрақам',org.account||'','text',false)+field('mfo','МФО',org.mfo||'','text',false)+
 field('phone','Автомактаб телефони',org.phone||'','tel',false)+field('trainingAddress','Машғулот манзили',org.trainingAddress||'','text',false));
 showModal('Автомактабнинг шартнома реквизитлари',fields,'Сақлаш',async v=>{
 await mutate('/api/organization','PUT',v,'Автомактаб реквизитлари сақланди.');
 });
 }catch(e){toast(e.message,true)}
}
function addEditStudent(existing){
 if(!allowed('students_write'))return;
 if(!data.groups.length){toast('Олдин гуруҳ яратинг.',true);setPage('groups');return}
 const s=existing||{name:'',phone:'',groupId:data.groups[0].id,join:iso(new Date()),fee:data.groups[0].fee,status:'Ўқимоқда',contractNo:contractNumberSuggestion(),contractDate:iso(new Date()),birthDate:'',passport:'',pinfl:'',address:'',payerName:'',payerPhone:'',courseStart:'',courseEnd:'',paymentDue:'',paymentTerms:'',contractNote:'',guardianName:'',contractCity:'',serviceType:'Комплекс',educationForm:'',trainingAddress:'',trainingProgram:'',theoryHours:'',practicalHours:'',practicalSessions:'',lessonSchedule:'',vehicleModel:'',externalFees:'',extraLessonFee:'',notificationChannel:'Телефон',paymentScheduleJson:'[]',practiceLogJson:'[]'};
 const groups=data.groups.map(g=>[g.id,`${g.name} · ${money(g.fee)}`]);
 const fields=contractSection('1. Ўқувчи маълумотлари','Шартнома тузишда зарур шахсий реквизитлар.',
   field('name','Ўқувчининг Ф.И.Ш.',s.name)+field('phone','Телефон рақами',s.phone,'tel')+
   field('birthDate','Туғилган санаси',s.birthDate||'','date',false)+field('passport','Паспорт / ID-карта серия ва рақами',s.passport||'','text',false)+
   field('pinfl','ЖШШИР (14 рақам)',s.pinfl||'','text',false)+field('address','Яшаш манзили',s.address||'','text',false))+
 contractSection('2. Шартнома реквизитлари','Шартнома рақами, санаси ва таълим шартлари.',
   field('contractNo','Шартнома рақами',s.contractNo||'','text',true)+field('contractDate','Шартнома тузилган сана',s.contractDate||iso(new Date()),'date',true)+
   field('groupId','Гуруҳ',s.groupId,'text',true,groups)+field('join','Қабул санаси',s.join,'date')+
   field('courseStart','Ўқиш бошланиш санаси',s.courseStart||'','date',false)+field('courseEnd','Ўқиш тугаш санаси',s.courseEnd||'','date',false)+
   field('fee','Шартнома суммаси (сўм)',s.fee,'number')+field('status','Ўқувчи ҳолати',s.status,'text',true,['Ўқимоқда','Тугатган','Тўхтатилган'].map(t=>[t,t])))+
 contractSection('3. Тўлов ва вакил реквизитлари','Зарур бўлса, тўловчи/қонуний вакил ҳақида маълумот киритинг.',
   field('payerName','Тўловчи / вакил Ф.И.Ш.',s.payerName||'','text',false)+field('payerPhone','Тўловчи телефони',s.payerPhone||'','tel',false)+
   field('paymentDue','Тўловнинг охирги санаси',s.paymentDue||'','date',false)+field('paymentTerms','Тўлов тартиби',s.paymentTerms||'','text',false)+
   field('contractNote','Шартнома бўйича изоҳ',s.contractNote||'','text',false))+
 contractSection('4. Намунадаги хизмат спецификацияси','1-илова учун ўқитиш шартларини тўлдиринг.',
   field('contractCity','Шартнома тузилган шаҳар/туман',s.contractCity||'','text',false)+
   field('guardianName','Қонуний вакил (агар бўлса)',s.guardianName||'','text',false)+
   field('serviceType','Хизмат тури',s.serviceType||'Комплекс','text',false,[['Назарий','Назарий'],['Амалий','Амалий'],['Комплекс','Комплекс']])+
   field('educationForm','Таълим шакли',s.educationForm||'','text',false)+
   field('trainingAddress','Таълим / машғулот манзили',s.trainingAddress||'','text',false)+
   field('trainingProgram','Дастур / меъёрий асос',s.trainingProgram||'','text',false)+
   field('theoryHours','Назарий соатлар сони',s.theoryHours||'','number',false)+
   field('practicalHours','Амалий соатлар сони',s.practicalHours||'','number',false)+
   field('practicalSessions','Амалий машғулотлар сони',s.practicalSessions||'','number',false)+
   field('lessonSchedule','Машғулотлар жадвали',s.lessonSchedule||'','text',false)+
   field('vehicleModel','Машина модели',s.vehicleModel||'','text',false)+
   field('externalFees','Нархга кирмайдиган харажатлар',s.externalFees||'','text',false)+
   field('extraLessonFee','Қўшимча дарс нархи',s.extraLessonFee||'','number',false)+
   field('notificationChannel','Хабар бериш усули',s.notificationChannel||'Телефон','text',false,[['Телефон','Телефон'],['SMS','SMS'],['Telegram','Telegram'],['Email','Email']]))+
 paymentScheduleFields(s)+practicalLogFields(s);
 showModal(existing?'Ўқувчи / шартнома реквизитларини таҳрирлаш':'Ўқувчи ва шартнома қўшиш',fields,existing?'Сақлаш':'Қўшиш',async v=>{
  const fee=Number(v.fee);
  if(!Number.isSafeInteger(fee)||fee<0||!v.name.trim()||!v.phone.trim()||!v.contractNo.trim()||!v.contractDate){toast('Ф.И.Ш., телефон, шартнома рақами, санаси ва суммаси тўғри киритилсин.',true);return}
  if(v.pinfl&&!/^\d{14}$/.test(v.pinfl)){toast('ЖШШИР айнан 14 рақамдан иборат.',true);return}
  if(v.courseStart&&v.courseEnd&&v.courseEnd<v.courseStart){toast('Ўқиш тугаш санаси бошланиш санасидан олдин.',true);return}
  serializeContractExtras(v);
  await mutate(existing?'/api/students/'+existing.id:'/api/students',existing?'PUT':'POST',{...v,fee},existing?'Шартнома реквизитлари янгиланди.':'Ўқувчи ва шартнома сақланди.');
 });
 if(!existing)document.getElementById('f_groupId').addEventListener('change',e=>{let g=group(e.target.value);if(g)document.getElementById('f_fee').value=g.fee});
 const passportInput=document.getElementById('f_passport');if(passportInput)passportInput.maxLength=40;
 const pinflInput=document.getElementById('f_pinfl');if(pinflInput){pinflInput.maxLength=14;pinflInput.inputMode='numeric';pinflInput.pattern='[0-9]{14}';}
}

function addEditGroup(existing){
 if(!allowed('groups_write'))return;
 let s=existing||{name:'',category:'B тоифа',teacher:'',start:iso(new Date()),days:'Душ, Чор, Жум',time:'09:00',capacity:20,fee:3600000,status:'Фаол'};
 showModal(existing?'Гуруҳни таҳрирлаш':'Янги гуруҳ',field('name','Гуруҳ номи',s.name)+field('category','Тоифа',s.category,'text',true,[['B тоифа','B тоифа'],['BC тоифа','BC тоифа'],['C тоифа','C тоифа'],['D тоифа','D тоифа']])+field('teacher','Ўқитувчи',s.teacher)+field('start','Бошланган сана',s.start,'date')+field('days','Дарс кунлари',s.days)+field('time','Дарс вақти',s.time,'time')+field('capacity','Ўринлар сони',s.capacity,'number')+field('fee','Шартнома нархи (сўм)',s.fee,'number')+field('status','Ҳолати',s.status,'text',true,[['Фаол','Фаол'],['Якунланган','Якунланган']]),existing?'Сақлаш':'Гуруҳ қўшиш',async v=>{
  const cap=Number(v.capacity),fee=Number(v.fee);
  if(!Number.isSafeInteger(cap)||cap<1||!Number.isSafeInteger(fee)||fee<0){toast('Сиғим ёки нарх нотўғри.',true);return}
  await mutate(existing?'/api/groups/'+existing.id:'/api/groups',existing?'PUT':'POST',{...v,capacity:cap,fee},'Гуруҳ сақланди.');
 });
}
function addPayment(){
 if(!allowed('payments_write'))return;
 let opts=data.students.filter(s=>debt(s)>0).map(s=>[s.id,`${s.name} · қарз ${money(debt(s))}`]);
 if(!opts.length){toast('Қарздор ўқувчи топилмади.',true);return}
 showModal('Янги тўлов киритиш',field('studentId','Ўқувчи',opts[0][0],'text',true,opts)+field('date','Тўлов санаси',iso(new Date()),'date')+field('amount','Сумма (сўм)',0,'number')+field('method','Тўлов усули','Нақд','text',true,[['Нақд','Нақд'],['Карта','Карта'],['Банк','Банк']])+field('note','Изоҳ','Тўлов','text',false),'Тўловни сақлаш',async v=>{
  const amount=Number(v.amount);
  if(!Number.isSafeInteger(amount)||amount<1){toast('Тўлов суммасини тўғри киритинг.',true);return}
  await mutate('/api/payments','POST',{...v,amount},'Тўлов базага сақланди.');
 });
}
async function askDelStudent(sid){if(!allowed('students_write'))return;let s=student(sid);if(s&&confirm(`${s.name} ўқувчисини ўчирасизми?`))await mutate('/api/students/'+sid,'DELETE',undefined,'Ўқувчи ўчирилди.')}
async function askDelGroup(gid){if(!allowed('groups_write'))return;if(confirm('Гуруҳни ўчирасизми?'))await mutate('/api/groups/'+gid,'DELETE',undefined,'Гуруҳ ўчирилди.')}
async function askDelPayment(pid){if(!allowed('payments_void'))return;let p=data.payments.find(p=>p.id===pid);if(p&&confirm(`${money(p.amount)} тўловни бекор қиласизми? Тарих сақланади.`))await mutate('/api/payments/'+pid+'/void','POST',{},'Тўлов бекор қилинди (аудитда сақланди).')}
async function saveAttendance(){if(!allowed('attendance_write')||!attGroup)return;
 const entries=Object.entries(attDraft).map(([studentId,status])=>({studentId,status}));
 if(!entries.length){toast('Ўзгариш белгиланмади.',true);return}
 if(await mutate('/api/attendance/upsert','POST',{groupId:attGroup,date:attDate,entries},`${entries.length} та давомат сақланди.`)){attDraft={};render();}
}
async function backup(){if(!allowed('backup'))return;try{
 let result=await api('/api/backup');download(`avtomaktab_data_${iso(new Date())}.json`,new Blob([JSON.stringify(result,null,2)],{type:'application/json'}));toast('Маълумотлар нусхаси юкланди.');
 }catch(e){toast(e.message,true)}}
async function loadSettings(){try{
 let [users,audit]=await Promise.all([api('/api/users'),api('/api/audit')]);usersCache=users.users;auditCache=audit.rows;if(page==='settings')render();
 }catch(e){toast(e.message,true)}}
function addUser(){if(!allowed('users'))return;
 const options=data.groups.map(g=>[g.id,g.name]);
 showModal('Ходим учун аккаунт',field('username','Логин (лотинча)', '')+field('password','Парол (12+ белги, рақам ва ҳарф)', '', 'password')+field('role','Роль','cashier','text',true,[['director','Директор'],['accountant','Бухгалтер'],['cashier','Кассир'],['teacher','Ўқитувчи']])+field('groupId','Ўқитувчи гуруҳи',options[0]?.[0]||'','text',false,[['','Танланмаган'],...options]),'Ходимни қўшиш',async v=>{
 if(v.password.length<12){toast('Парол камида 12 белги.',true);return}
 if(await mutate('/api/users','POST',v,'Ходим аккаунти яратилди.'))loadSettings();
 });
}
async function disableUser(id){if(!allowed('users')||!confirm('Бу ходимнинг кириши бекор қилинсинми?'))return;
 if(await mutate('/api/users/'+id+'/disable','POST',{},'Ходим кириши тўхтатилди.'))loadSettings();}
async function enableUser(id){if(!allowed('users'))return;if(await mutate('/api/users/'+id+'/enable','POST',{},'Ходим фаоллаштирилди.'))loadSettings();}
function resetUserPassword(id){if(!allowed('users'))return;
 const person=usersCache.find(v=>v.id===id);if(!person)return;
 showModal('Паролни алмаштириш: '+person.username,field('password','Янги парол (12+ белги)', '', 'password'), 'Паролни ўрнатиш',async v=>{
 if(await mutate('/api/users/'+id+'/reset-password','POST',v,'Парол ўзгартирилди.'))loadSettings();
 });
}
function changeOwnPassword(){showModal('Ўз паролимни алмаштириш',field('oldPassword','Жорий парол','','password')+field('newPassword','Янги парол (12+ белги)','','password'),'Алмаштириш',async v=>{
 try{await api('/api/change-password','POST',v);closeModal();showLogin();toast('Парол ўзгарди. Янги парол билан киринг.')}catch(e){toast(e.message,true)}
 });}
async function logout(){if(PUBLIC_DEMO){location.href='/admin';return}try{await api('/api/logout','POST',{})}catch(e){}showLogin();}
function renderSettings(){
 if(PUBLIC_DEMO) return `<section class="panel"><h2>Танишув режими</h2><p>Ушбу очиқ саҳифада ҳақиқий ўқувчилар ва тўловлар маълумотлари кўрсатилмайди ёки сақланмайди.</p><p>Директор учун ҳимояланган бошқарув қисмига кириш:</p><a class="btn primary" href="/admin">Директор кириши →</a></section>`;
 const profile=`<section class="panel"><div class="panelhead"><div><h2>Аккаунт ва хавфсизлик</h2><p>Маълумотлар марказий серверда сақланади</p></div></div><div class="info-row"><span>Фойдаланувчи</span><b>${esc(currentUser.username)}</b></div><div class="info-row"><span>Роль</span><b>${esc(roleName[currentUser.role])}</b></div><div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:20px"><button class="btn primary" data-action="change-password">Паролимни ўзгартириш</button><button class="btn" data-action="logout">Чиқиш</button>${allowed('backup')?`<button class="btn" data-action="backup">${ic('download')} JSON нусхаси</button>`:''}</div><p class="hinttext">PostgreSQL учун автоматик захира бепул тарифда кафолатланмайди. Директор JSON маълумотларини мунтазам экспорт қилиши керак. HTTPS шарт.</p></section>`;
 const users=allowed('users')?`<section class="panel"><div class="panelhead"><div><h2>Ходимларни бошқариш</h2><p>Рухсатлар серверда текширилади</p></div><button class="btn primary" data-action="add-user">＋ Ходим</button></div><div class="tablewrap"><table><thead><tr><th>Логин</th><th>Роль</th><th>Ҳолат</th><th>Амаллар</th></tr></thead><tbody>${usersCache.map(v=>`<tr><td class="strong">${esc(v.username)}</td><td>${esc(roleName[v.role]||v.role)}</td><td>${v.active?'Фаол':'Ўчирилган'}</td><td><div class="actions">${v.active?`<button class="btn" data-action="reset-user" data-id="${v.id}">Парол</button><button class="btn" data-action="disable-user" data-id="${v.id}">Блоклаш</button>`:`<button class="btn" data-action="enable-user" data-id="${v.id}">Фаоллаштириш</button>`}</div></td></tr>`).join('')||'<tr><td colspan="4">Ходимлар топилмади.</td></tr>'}</tbody></table></div></section>`:'';
 const audit=allowed('audit')?`<section class="panel"><div class="panelhead"><div><h2>Амалиётлар журнали</h2><p>Охирги 100 та амал</p></div></div><div class="tablewrap"><table><thead><tr><th>Сана</th><th>Ходим</th><th>Амал</th><th>Тур</th><th>Изоҳ</th></tr></thead><tbody>${auditCache.map(v=>`<tr><td>${esc(v.at.slice(0,19).replace('T',' '))}</td><td>${esc(v.actor)}</td><td>${esc(v.action)}</td><td>${esc(v.kind)}</td><td>${esc(v.details)}</td></tr>`).join('')}</tbody></table></div></section>`:'';
 return `<div class="settings-grid">${profile}${users}</div>${audit?`<div style="margin-top:20px">${audit}</div>`:''}`;
}
function handleAction(el){const action=el.dataset.action,sid=el.dataset.id;
 if(action==='close-modal'){closeModal();return}
 if(action==='contract-pdf'&&allowed('students_write')){window.location.assign('/api/students/'+encodeURIComponent(sid)+'/contract.pdf');return}if(action==='edit-organization')editOrganization();if(action==='view-student-contract')showStudentContract(sid);if(action==='add-student')addEditStudent();if(action==='edit-student')addEditStudent(student(sid));if(action==='del-student')askDelStudent(sid);
 if(action==='add-group')addEditGroup();if(action==='edit-group')addEditGroup(group(sid));if(action==='del-group')askDelGroup(sid);
 if(action==='add-payment')addPayment();if(action==='del-payment')askDelPayment(sid);
 if(action==='view-group'){studentFilter.group=sid;studentFilter.q='';studentFilter.status='';setPage('students')}
 if(action==='attendance-select'&&allowed('attendance_write')){attDraft[sid]=el.dataset.status;render()}
 if(action==='save-attendance')saveAttendance();if(action==='csv-report'&&allowed('reports'))exportCSV();
 if(action==='print'&&allowed('reports'))window.print();if(action==='backup')backup();
 if(action==='add-user')addUser();if(action==='disable-user')disableUser(sid);if(action==='enable-user')enableUser(sid);
 if(action==='reset-user')resetUserPassword(sid);if(action==='change-password')changeOwnPassword();if(action==='logout')logout();
}
document.addEventListener('click',e=>{const p=e.target.closest('[data-page]');if(p){setPage(p.dataset.page);return}const a=e.target.closest('[data-action]');if(a)handleAction(a);if(e.target.id==='modalBackdrop')closeModal()});
document.addEventListener('input',e=>{const t=e.target;if(t.id==='studentSearch'){let pos=t.selectionStart;studentFilter.q=t.value;render();let a=document.getElementById('studentSearch');a?.focus();a?.setSelectionRange(pos,pos)}if(t.id==='paymentSearch'){let pos=t.selectionStart;paymentFilter.q=t.value;render();let a=document.getElementById('paymentSearch');a?.focus();a?.setSelectionRange(pos,pos)}});
document.addEventListener('change',e=>{const t=e.target;
 if(t.matches('.date-entry-picker')){
   const dst=document.getElementById(t.dataset.dateTarget);if(dst){dst.value=dateForEntry(t.value);dst.setCustomValidity('');if(dst.dataset.dateFilter)dst.dispatchEvent(new Event('change',{bubbles:true}))}
   return;
 }
 if(t.dataset.dateFilter){const date=applyEditedDate(t);if(date===null)return;
   if(t.id==='attDate'){if(!date){toast('Дарс санасини киритинг.',true);return}attDate=date;attDraft={};render();return}
   if(t.id==='reportFrom'){if(!date||date>reportTo){toast('Давр боши санасини тўғри киритинг.',true);return}reportFrom=date;render();return}
   if(t.id==='reportTo'){if(!date||date<reportFrom){toast('Давр охири санасини тўғри киритинг.',true);return}reportTo=date;render();return}
 }
 if(t.id==='studentGroupFilter'){studentFilter.group=t.value;render()}if(t.id==='studentStatusFilter'){studentFilter.status=t.value;render()}if(t.id==='paymentMethodFilter'){paymentFilter.method=t.value;render()}if(t.id==='attGroup'){attGroup=t.value;attDraft={};render()}if(t.id==='attDate'){attDate=t.value;attDraft={};render()}if(t.id==='reportFrom'){if(t.value>reportTo){toast('Бошланиш санаси тугаш санасидан кейин бўлиши мумкин эмас.',true);render();return}reportFrom=t.value;render()}if(t.id==='reportTo'){if(t.value<reportFrom){toast('Тугаш санаси бошланиш санасидан олдин бўлиши мумкин эмас.',true);render();return}reportTo=t.value;render()}if(t.id==='restoreFile'){restoreFile(t.files?.[0])}});
document.addEventListener('input',e=>{if(e.target.matches('.date-entry-text'))e.target.setCustomValidity('')});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});document.getElementById('menuToggle').onclick=()=>{document.getElementById('sidebar').classList.toggle('open');document.getElementById('screenDim').classList.toggle('open')};document.getElementById('screenDim').onclick=closeMenu;
document.getElementById('pw-eye').onclick=()=>{let x=document.getElementById('loginPassword'),b=document.getElementById('pw-eye');let on=x.type==='password';x.type=on?'text':'password';b.setAttribute('aria-pressed',String(on));b.setAttribute('aria-label',on?'Паролни яшириш':'Паролни кўрсатиш')};
document.getElementById('loginForm').addEventListener('submit',async e=>{
 e.preventDefault();const btn=document.getElementById('loginBtn');btn.disabled=true;document.getElementById('loginError').textContent='';
 try{const v=await api('/api/login','POST',{username:document.getElementById('loginUser').value,password:document.getElementById('loginPassword').value,remember30:document.getElementById('remember30').checked});currentUser=v.user;csrf=v.csrf;await enterApp()}
 catch(e){document.getElementById('loginError').textContent=e.message}
 finally{btn.disabled=false}
});
setInterval(()=>{if(!PUBLIC_DEMO&&currentUser&&!modal)loadState().catch(e=>toast(e.message,true))},45000);
window.addEventListener('focus',()=>{if(!PUBLIC_DEMO&&currentUser&&!modal)loadState().catch(()=>{})});
init();

})();