"""Protected Cyrillic student training agreement PDF (DRAFT only)."""
from io import BytesIO
from pathlib import Path
import os
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether

# The application does NOT distribute a font file. The server uses a preinstalled
# Cyrillic-capable system font; configure CONTRACT_PDF_FONT if necessary.
def find_contract_font():
    choices = [os.environ.get('CONTRACT_PDF_FONT', ''),
               '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
               '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
               '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
               '/usr/share/fonts/TTF/DejaVuSans.ttf']
    for name in choices:
        if name and Path(name).is_file(): return Path(name)
    raise RuntimeError('PDF учун кирилл шрифт серверда топилмади. CONTRACT_PDF_FONT ни созланг.')


def _str(s):
    return escape(str(s or '—'))

def _date(s):
    try:
        y,m,d=str(s).split('-');return f'{d}.{m}.{y}'
    except ValueError:
        return '—'

def generate_contract_pdf(student, group):
    if 'ContractUnicode' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('ContractUnicode', str(find_contract_font())))
    org_name=os.environ.get('CONTRACT_ORG_NAME','IDIAL MASTER MAKTAB AVTOMAKTAB')
    org_inn=os.environ.get('CONTRACT_ORG_INN','(тўлдирилади)')
    org_addr=os.environ.get('CONTRACT_ORG_ADDRESS','(тўлдирилади)')
    org_phone=os.environ.get('CONTRACT_ORG_PHONE','(тўлдирилади)')
    org_bank=os.environ.get('CONTRACT_ORG_BANK','(тўлдирилади)')
    org_director=os.environ.get('CONTRACT_ORG_DIRECTOR','(тўлдирилади)')
    b=BytesIO()
    doc=SimpleDocTemplate(b,pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=16*mm,bottomMargin=17*mm,title='Ўқув шартномаси - ЛОЙИҲА',author='IDIAL MASTER MAKTAB')
    normal=ParagraphStyle('u',fontName='ContractUnicode',fontSize=8.7,leading=12.5,spaceAfter=4)
    compact=ParagraphStyle('c',parent=normal,fontSize=8.2,leading=11.4,spaceAfter=2)
    h=ParagraphStyle('h',parent=normal,fontSize=10.8,leading=14,spaceBefore=8,spaceAfter=4)
    title=ParagraphStyle('title',parent=normal,alignment=TA_CENTER,fontSize=12.8,leading=16,spaceAfter=6)
    small=ParagraphStyle('small',parent=normal,fontSize=7.7,leading=11,textColor=colors.HexColor('#6b7787'))
    def P(txt,style=normal):return Paragraph(txt,style)
    def val(x):return _str(x)
    story=[P('ЎҚУВ ХИЗМАТЛАРИНИ КЎРСАТИШ ШАРТНОМАСИ',title),
           P('<b>ЛОЙИҲА. Ташкилот реквизитларини текшириб, томонлар имзолагандан кейин ишлатилади.</b>',small),
           P(f'Шартнома № <b>{val(student["contract_no"])}</b> &nbsp;&nbsp;&nbsp; Сана: <b>{_date(student["contract_date"])}</b>',normal),
           P(f'<b>{val(org_name)}</b> (кейинги ўринларда «Ижрочи»), директор {val(org_director)} орқали бир томондан ва <b>{val(student["name"])}</b> (кейинги ўринларда «Ўқувчи») иккинчи томондан мазкур шартномани туздилар.',normal),
           P('1. Шартнома предмети',h),
           P(f'1.1. Ижрочи Ўқувчига ҳайдовчиларни тайёрлаш бўйича ўқув хизматларини кўрсатади. Тоифа: <b>{val(group["category"] if group else "")}</b>. Гуруҳ: <b>{val(group["name"] if group else "")}</b>.',normal),
           P(f'1.2. Ўқиш даври: <b>{_date(student["course_start"])}</b> дан <b>{_date(student["course_end"])}</b> гача. Дарс жадвали амалдаги ўқув режаси ва келишилган машғулотлар асосида белгиланади.',normal),
           P('2. Хизмат ҳақи ва тўлов тартиби',h),
           P(f'2.1. Шартнома қиймати: <b>{int(student["fee"]):,} сўм</b>. Тўлов муддати: <b>{_date(student["payment_due"])}</b>.',normal),
           P(f'2.2. Тўлов шарти: <b>{val(student["payment_terms"] or "Томонлар келишувига мувофиқ")}</b>. Тўловлар Ижрочининг расмий реквизитларига ёки тасдиқланган кассасига амалга оширилади.',normal),
           P('3. Томонларнинг ҳуқуқ ва мажбуриятлари',h),
           P('3.1. Ижрочи тасдиқланган дастур асосида дарсларни ташкил қилади, ўқитувчи ва инструкторлар иштирокини таъминлайди ҳамда давоматни юритади.',normal),
           P('3.2. Ўқувчи дарсларга ўз вақтида қатнашади, ички тартиб ва хавфсизлик қоидаларига риоя қилади, белгиланган ҳақни тўлайди.',normal),
           P('3.3. Амалий машғулотлар белгиланган тартибда, техник жиҳатдан соз ўқув автотранспортида ўтказилади.',normal),
           P('4. Шартномани ўзгартириш ва бекор қилиш',h),
           P('4.1. Шартнома шартлари томонлар келишуви билан ёзма равишда ўзгартирилиши мумкин. Бекор қилиш ва қайтариладиган маблағ масаласи амалдаги қонунчилик ҳамда ҳақиқатда кўрсатилган хизмат ҳажмига мувофиқ ҳал этилади.',normal),
           P('4.2. Низолар аввало музокара йўли билан ҳал этилади; келишувга эришилмаса, амалдаги қонунчиликда белгиланган тартиб қўлланади.',normal),
           P('5. Томонлар реквизитлари',h)]
    inf=[('Ташкилот',org_name),('СТИР (ИНН)',org_inn),('Манзил',org_addr),('Телефон',org_phone),('Банк / ҳисоб рақами',org_bank),('Директор',org_director),('Ўқувчи',student['name']),('Телефон',student['phone']),('Паспорт / ID',student['passport']),('ЖШШИР',student['pinfl']),('Манзил',student['address']),('Тўловчи / вакил',student['payer_name']),('Тўловчи телефон',student['payer_phone'])]
    tb=Table([[P(val(k),compact),P(val(v),compact)] for k,v in inf],colWidths=[45*mm,127*mm],hAlign='LEFT')
    tb.setStyle(TableStyle([('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#dce4ed')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3)]))
    story += [tb,Spacer(1,4*mm),P('Ижрочи: ________________________ &nbsp;&nbsp;&nbsp; Ўқувчи: ________________________',normal),P('Ушбу ҳужжат автоматик тузилган лойиҳа. Имзолашдан аввал ташкилот реквизитлари ва ҳуқуқий шартлар текширилиши шарт.',small)]
    def footer(canvas, doc):
        canvas.saveState();canvas.setFont('ContractUnicode',7.5);canvas.setFillColor(colors.grey)
        canvas.drawRightString(A4[0]-18*mm,11*mm,f'{doc.page}-бет · Шартнома лойиҳаси');canvas.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return b.getvalue()
