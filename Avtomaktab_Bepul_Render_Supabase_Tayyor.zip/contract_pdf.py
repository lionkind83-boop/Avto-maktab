"""Student contract PDF. The 33 substantive numbered clauses are copied verbatim
from the owner's attached 5-page Word sample into contract_template.json.
Only document-specific lines and the appendix tables are populated dynamically.
"""
from io import BytesIO
from pathlib import Path
from html import escape
import json
import os
import hashlib
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.graphics.barcode.qr import QrCodeWidget
from reportlab.graphics.shapes import Drawing

BASE=Path(__file__).resolve().parent
TEXT=json.loads((BASE/'contract_template.json').read_text(encoding='utf-8'))
CHAPTERS=[
 ('1','ШАРТНОМА ПРЕДМЕТИ',4),
 ('2','ИЖРОЧИНИНГ МАЖБУРИЯТЛАРИ ВА ҲУҚУҚЛАРИ',2),
 ('3','ЎҚУВЧИНИНГ МАЖБУРИЯТЛАРИ ВА ҲУҚУҚЛАРИ',2),
 ('4','НАРХ, ҲИСОБ-КИТОБ ВА ТЎЛОВ',4),
 ('5','ДАРС ЖАДВАЛИ, ДАВОМАТ ВА ҚАЙТА МАШҒУЛОТ',4),
 ('6','АМАЛИЙ МАШҒУЛОТЛАРДА ХАВФСИЗЛИК ВА ЗАРАР',3),
 ('7','НАТИЖА ВА ҲУЖЖАТЛАРНИ РАСМИЙЛАШТИРИШ',3),
 ('8','ШАРТНОМАНИ ЎЗГАРТИРИШ, БЕКОР ҚИЛИШ ВА ҚАЙТАРИМ',4),
 ('9','ШАХСГА ДОИР МАЪЛУМОТЛАР',2),
 ('10','НИЗОЛАР, ФОРС-МАЖОР ВА ЯКУНИЙ ҚОИДАЛАР',5),
]

def _s(v):
    return escape(str(v if v is not None and str(v).strip() else '________________'))

def _date(v):
    val=str(v or '').strip()
    if len(val)==10 and val[4]=='-' and val[7]=='-': return f'{val[8:]}.{val[5:7]}.{val[:4]}'
    return _s(v)

def _number(v):
    try:return f'{int(v):,}'.replace(',',' ')
    except (TypeError,ValueError):return _s(v)

def _list(v,limit):
    try:
        x=json.loads(v or '[]')
        return x[:limit] if isinstance(x,list) else []
    except (ValueError,TypeError):return []

def _font():
    candidates=[os.environ.get('CONTRACT_PDF_FONT',''),
     '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
     '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf',
     '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf']
    for candidate in candidates:
        if candidate and Path(candidate).is_file():return str(candidate)
    raise RuntimeError('Кирилл алифбоси учун PDF шрифт топилмади.')

def generate_contract_pdf(student,group,organization=None):
    if 'IdialContract' not in pdfmetrics.getRegisteredFontNames():
        name=_font();pdfmetrics.registerFont(TTFont('IdialContract',name))
        bold=str(Path(name).with_name('DejaVuSans-Bold.ttf'))
        if Path(bold).exists():
            pdfmetrics.registerFont(TTFont('IdialContractBold',bold))
            registerFontFamily('IdialContract',normal='IdialContract',bold='IdialContractBold',italic='IdialContract',boldItalic='IdialContractBold')
    org={'name':'IDIAL MASTER MAKTAB'}
    org.update(organization or {})
    val=lambda k:_s(student[k] if k in student.keys() else '')
    orgval=lambda k:_s(org.get(k,''))
    category=_s(group['category'] if group else '')
    # QR intentionally exposes no personal information. It identifies the contract,
    # but is NOT a digital signature and offers no public validity verification.
    raw_no=str(student['contract_no'] if 'contract_no' in student.keys() else '').strip()
    raw_date=str(student['contract_date'] if 'contract_date' in student.keys() else '').strip()
    raw_id=str(student['id'] if 'id' in student.keys() else '').strip()
    orgname=str(org.get('name') or 'IDIAL MASTER MAKTAB')
    ref=hashlib.sha256((orgname+'|'+raw_no+'|'+raw_date+'|'+raw_id).encode('utf8')).hexdigest()[:16].upper()
    qr_payload=f'IDIAL MASTER MAKTAB\nCONTRACT: {raw_no}\nDATE: {_date(raw_date)}\nREF: {ref}'
    qrw=QrCodeWidget(qr_payload,barLevel='M')
    x0,y0,x1,y1=qrw.getBounds()
    side=33*mm
    qr_image=Drawing(side,side,transform=[side/(x1-x0),0,0,side/(y1-y0),-side*x0/(x1-x0),-side*y0/(y1-y0)])
    qr_image.add(qrw)
    pay=_list(student['payment_schedule_json'] if 'payment_schedule_json' in student.keys() else '',4)
    logs=_list(student['practice_log_json'] if 'practice_log_json' in student.keys() else '',12)
    total=int(student['fee'])
    base=BytesIO()
    doc=SimpleDocTemplate(base,pagesize=A4,topMargin=17*mm,bottomMargin=16*mm,
        leftMargin=16*mm,rightMargin=16*mm,title='Ҳайдовчиларни тайёрлаш бўйича шартнома',
        author='IDIAL MASTER MAKTAB')
    normal=ParagraphStyle('normal1',fontName='IdialContract',fontSize=8.45,leading=12.45,spaceAfter=4,allowWidows=0,allowOrphans=0)
    compact=ParagraphStyle('compact1',parent=normal,fontSize=7.7,leading=11,spaceAfter=2)
    micro=ParagraphStyle('micro1',parent=normal,fontSize=7.3,leading=10.5,spaceAfter=1)
    head=ParagraphStyle('chapter1',parent=normal,fontSize=10.2,leading=14,spaceBefore=10,spaceAfter=5,keepWithNext=1)
    centered=ParagraphStyle('center1',parent=normal,fontSize=12,leading=17,spaceAfter=10,alignment=TA_CENTER)
    subtitle=ParagraphStyle('subtitle1',parent=normal,fontSize=9.4,leading=13,spaceAfter=6,alignment=TA_CENTER)
    muted=ParagraphStyle('muted1',parent=normal,fontSize=7.2,leading=10,textColor=colors.HexColor('#657386'))
    def P(t,sty=normal):return Paragraph(t,sty)
    def lines_table(rows,widths,header=False):
        tbl=Table([[t if isinstance(t, Paragraph) else P(str(t),compact) for t in row] for row in rows],colWidths=widths,repeatRows=1 if header else 0,hAlign='CENTER')
        rules=[('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#cfdae9'))]
        if header:rules += [('BACKGROUND',(0,0),(-1,0),colors.HexColor('#eaf0fa'))]
        tbl.setStyle(TableStyle(rules))
        return tbl
    story=[P('ҲАЙДОВЧИЛАРНИ ТАЙЁРЛАШ БЎЙИЧА<br/>ҲАҚ ЭВАЗИГА ТАЪЛИМ ХИЗМАТЛАРИ КЎРСАТИШ<br/>ШАРТНОМАСИ',centered),
        Table([[P(f'№ <b>{val("contract_no")}</b><br/>Сана: <b>{_date(student["contract_date"])}</b><br/><b>{orgval("city") if org.get("city") else val("contract_city")}</b> шаҳри/тумани',normal),
                [qr_image,P('QR — шартнома коди',micro)]]], colWidths=[137*mm,39*mm], style=TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('BOTTOMPADDING',(0,0),(-1,-1),7)])),
        P(f'«<b>{orgval("name")}</b>» (кейинги ўринларда «Ижрочи»), СТИР <b>{orgval("inn")}</b>, ҳайдовчиларни тайёрлаш фаолияти бўйича лицензия/рухсат реквизитлари <b>{orgval("license")}</b>, директор <b>{orgval("director")}</b> номидан, Устав асосида ҳаракат қилувчи бир томондан ва фуқаро <b>{val("name")}</b> (кейинги ўринларда «Ўқувчи») иккинчи томондан қуйидагилар ҳақида ушбу шартномани туздилар.'),
        P('Агар Ўқувчи вояга етмаган бўлса, қонун талаб қилган ҳолларда шартнома унинг қонуний вакили <b>'+val('guardian_name')+'</b> иштирокида/розилиги билан расмийлаштирилади.')]
    for part,title,count in CHAPTERS:
        story.append(P(f'{part}. {title}',head))
        for index in range(1,count+1):
            item=f'{part}.{index}'
            txt=TEXT[item]
            if item=='1.2':
                txt=(f'1.2. Тоифа/тоифалар: <b>{category}</b>. Таълим шакли: <b>{val("education_form")}</b>. '
                 f'Таълим олиш манзили: <b>{val("training_address") if student["training_address"] else orgval("trainingAddress")}</b>. '
                 f'Машғулотлар бошланиши: <b>{_date(student["course_start"])}</b>; '
                 f'режалаштирилган якун: <b>{_date(student["course_end"])}</b>.')
            elif item=='4.1':
                txt=f'4.1. Шартнома умумий қиймати: <b>{_number(total)} ({val("contract_note") if student["contract_note"] else "сумма ёзувда тўлдирилади"}) сўм</b>. Тўлов босқичлари, муддатлари, таълим ҳақига кирмайдиган хизматлар ва қўшимча харажатлар 1-иловада кўрсатилади.'
            story.append(P(escape(txt) if item not in {'1.2','4.1'} else txt,normal))
    # 11: exact requested requisites, all editable from a protected organization record
    story.append(P('11. ТОМОНЛАР РЕКВИЗИТЛАРИ ВА ИМЗОЛАРИ',head))
    executor=[('Номи',orgval('name')),('СТИР',orgval('inn')),('Лицензия / рухсат',orgval('license')),('Юридик манзил',orgval('address')),('Банк',orgval('bank')),('Ҳ/р',orgval('account')),('МФО',orgval('mfo')),('Тел.',orgval('phone')),('Директор',orgval('director'))]
    learner=[('Ф.И.Ш.',val('name')),('ЖШШИР',val('pinfl')),('Паспорт/ID',val('passport')),('Манзил',val('address')),('Тел.',val('phone')),('Қонуний вакил',val('guardian_name')),('Тўловчи',val('payer_name')),('Тўловчи телефони',val('payer_phone'))]
    paired=[ [P('<b>ИЖРОЧИ (АВТОМАКТАБ)</b>',compact),P('<b>ЎҚУВЧИ / ҚОНУНИЙ ВАКИЛ</b>',compact)] ]
    for i in range(max(len(executor),len(learner))):
        a=executor[i] if i<len(executor) else ('','')
        b=learner[i] if i<len(learner) else ('','')
        paired.append([P(f'{a[0]}: {a[1]}',compact),P(f'{b[0]}: {b[1]}',compact)])
    paired.append([P('Имзо: ____________________ М.Ў. (мавжуд бўлса)',compact),P('Имзо: ____________________',compact)])
    story += [lines_table(paired,[88*mm,88*mm]),PageBreak()]

    # Annex 1: all fields of the submitted sample, including 4 staged payments.
    story.append(P('1-ИЛОВА. ХИЗМАТ СПЕЦИФИКАЦИЯСИ ВА ТЎЛОВ ГРАФИГИ',subtitle))
    story.append(P(f'{_date(student["contract_date"])} йилдаги № {val("contract_no")} шартномага',compact))
    details=[('Кўрсаткич','Маълумот'),
      ('Ўқувчи Ф.И.Ш.',val('name')),
      ('Тайёрлаш/қайта тайёрлаш тоифаси',category),
      ('Хизмат тури',val('service_type')),
      ('Назарий машғулотлар',val('theory_hours')+' академик соат / кирмайди'),
      ('Амалий бошқариш машғулотлари',val('practical_hours')+' академик соат; '+val('practical_sessions')+' машғулот'),
      ('Дастур/меъёрий асос',val('training_program')),
      ('Машғулот манзили ва жадвали',val('training_address')+'; '+val('lesson_schedule')),
      ('Амалий машина модели/тури',val('vehicle_model')),
      ('Бошланиш ва тугаш санаси',_date(student['course_start'])+' — '+_date(student['course_end'])),
      ('Курснинг жами нархи',_number(total)+' сўм'),
      ('Нархга кирмайдиган ташқи тўловлар',val('external_fees')),
      ('Қўшимча дарс нархи (агар бўлса)',_number(student['extra_lesson_fee'])+' сўм/соат'),
      ('Алоқа/огоҳлантириш канали',val('notification_channel'))]
    story += [lines_table(details,[69*mm,107*mm],header=True),Spacer(1,5*mm),P('Тўлов графиги',head)]
    payrows=[('№','Тўлов муддати','Сумма (сўм)','Изоҳ')]
    for i in range(4):
        row=pay[i] if i<len(pay) else {}
        payrows.append((str(i+1),_date(row.get('date','')),_number(row.get('amount','')), _s(row.get('note',''))))
    summation=sum(int(row.get('amount',0) or 0) for row in pay)
    payrows.append(('','ЖАМИ',_number(summation) if pay else '____________',''))
    story += [lines_table(payrows,[13*mm,46*mm,43*mm,74*mm],header=True),Spacer(1,4*mm),
      P('Томонлар 1-илова мазмуни, хусусан, ўқитиладиган хизматлар таркиби, соатлар, тўловлар ва нархга кирмайдиган харажатлар билан танишганларини тасдиқлайдилар.'),
      P('Ижрочи вакили: ____________________ / ____________________'),
      P('Ўқувчи (вакили): ____________________ / ____________________'),PageBreak()]

    # Annex 2: practical driving lesson ledger (12 rows from the original sample).
    story.append(P('2-ИЛОВА. АМАЛИЙ МАШҒУЛОТЛАР ҲИСОБИ ВАРАҒИ',subtitle))
    story.append(P(f'Шартнома № {val("contract_no")} &nbsp; Ўқувчи: {val("name")}',normal))
    story.append(P('Ушбу варақ давомат ва амалда кўрсатилган соатларни тасдиқлаш учун мўлжалланган. Электрон ҳисоб тизими ишлатилса, мазкур маълумотлар тегишли тартибда электрон шаклда юритилиши мумкин.',normal))
    rows=[('№','Сана','Машғулот вақти/соати','Ўқув мавзуси ёки йўналиши','Йўриқчи имзоси','Ўқувчи имзоси')]
    for i in range(12):
        x=logs[i] if i<len(logs) else {}
        rows.append((str(i+1),_date(x.get('date','')),_s(x.get('hours','')),_s(x.get('topic','')),'________','________'))
    story.append(lines_table(rows,[9*mm,28*mm,35*mm,55*mm,25*mm,24*mm],header=True))
    total_hours=sum(float(x.get('hours') or '0') for x in logs if str(x.get('hours') or '').replace('.','',1).isdigit())
    remaining=max(0,int(student['practical_hours'] or 0)-total_hours)
    story.extend([Spacer(1,5*mm),P(f'Жами ўтилган амалий машғулот: {_number(int(total_hours))} соат. &nbsp; Қолдиқ: {_number(int(remaining))} соат.'),P('Тузган йўриқчи: ____________________ &nbsp;&nbsp; Ўқувчи: ____________________')])
    story.append(Spacer(1,5*mm))
    story.append(P('QR кодда шартнома рақами, санаси ва назорат идентификатори бор. У электрон имзо ёки давлат реестрида тасдиқлаш вазифасини бажармайди.',muted))
    story.append(P('Эслатма: Бу ҳужжат юкланган намунага асосланган, реквизитлар тўлиқ тўлдирилиши ва имзолашдан аввал маҳаллий ҳуқуқшунос томонидан текширилиши тавсия қилинади.',muted))
    def footer(canvas,doc):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor('#dbe4f0'))
        canvas.line(16*mm,13*mm,A4[0]-16*mm,13*mm)
        canvas.setFont('IdialContract',7)
        canvas.setFillColor(colors.HexColor('#758298'))
        canvas.drawString(16*mm,9.2*mm,'Автомактаб • Ўқувчи билан шартнома')
        canvas.drawRightString(A4[0]-16*mm,9.2*mm,f'{doc.page}-бет')
        canvas.restoreState()
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    return base.getvalue()
