#!/usr/bin/env python3
"""Apply the legal contract print/PDF extension to an Avtomaktab site ZIP safely.

Requires an ORIGINAL copy of Avtomaktab_Bepul_Render_Supabase_Tayyor.zip
in the same folder. Does not modify the source zip.
"""
from pathlib import Path
import sys
import zipfile

source = Path(sys.argv[1]) if len(sys.argv) >= 2 else Path('Avtomaktab_Bepul_Render_Supabase_Tayyor.zip')
target = Path(sys.argv[2]) if len(sys.argv) >= 3 else Path('Avtomaktab_Shartnoma_PDF_Yangilangan.zip')
addon_file = Path(__file__).resolve().parent / 'contract-addon.js'
if not source.is_file():
    sys.exit(f'ERROR: File not found: {source}')
if source.resolve() == target.resolve():
    sys.exit('ERROR: Input and output must be different files.')
addon = addon_file.read_text(encoding='utf-8')
with zipfile.ZipFile(source) as z:
    names = set(z.namelist())
    if 'public/app.js' not in names:
        sys.exit('ERROR: Missing public/app.js in source ZIP.')
    app = z.read('public/app.js').decode('utf-8')
    if 'function openStudentLegalContract' in app:
        sys.exit('ERROR: Contract extension already installed; refusing duplicate patch.')

    def single_replace(a, old, new):
        count = a.count(old)
        if count != 1:
            sys.exit(f'ERROR: Required source anchor must occur once, found {count}. Aborting safely.\n{old[:90]}')
        return a.replace(old, new, 1)

    app = single_replace(app,
        "['add-student','edit-student','del-student','view-student-contract'].includes(a)",
        "['add-student','edit-student','del-student','view-student-contract','print-student-contract'].includes(a)")
    app = single_replace(app,
        '<button class="btn" title="Шартнома реквизитлари" data-action="view-student-contract" data-id="${s.id}">Реквизитлар</button>',
        '<button class="btn" title="Шартнома реквизитлари" data-action="view-student-contract" data-id="${s.id}">Реквизитлар</button><button class="btn primary" title="Шартномани чоп этиш ёки PDF сақлаш" data-action="print-student-contract" data-id="${s.id}">Шартнома / PDF</button>')
    app = single_replace(app,
        "if(action==='view-student-contract')showStudentContract(sid);",
        "if(action==='print-student-contract'){openStudentLegalContract(sid);return}if(action==='view-student-contract')showStudentContract(sid);")
    if not app.rstrip().endswith('})();'):
        sys.exit('ERROR: app.js closure not found; aborting safely.')
    point = app.rfind('})();')
    app = app[:point] + '\n' + addon + '\n' + app[point:]

    with zipfile.ZipFile(target, 'w') as out:
        for info in z.infolist():
            if info.filename == 'public/app.js':
                out.writestr(info, app.encode('utf-8'))
            else:
                out.writestr(info, z.read(info.filename))

with zipfile.ZipFile(target) as patched:
    assert patched.testzip() is None
    js = patched.read('public/app.js').decode('utf-8')
    assert js.count('openStudentLegalContract(sid)') >= 1
    assert 'Шартнома / PDF' in js
print(f'OK: {target.resolve()} ({target.stat().st_size:,} bytes)')
