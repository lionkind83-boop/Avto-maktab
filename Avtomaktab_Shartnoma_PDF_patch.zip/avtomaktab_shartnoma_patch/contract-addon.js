// Student contract preview & print/PDF add-on. Runs inside the existing app.js IIFE.
// Uses only data already delivered by /api/state to the authorised students_write user.
function openStudentLegalContract(sid) {
  if (PUBLIC_DEMO || !allowed('students_write')) { toast('Шартномани кўришга рухсат йўқ.', true); return; }
  const s = student(sid);
  if (!s) { toast('Ўқувчи топилмади.', true); return; }
  const g = group(s.groupId) || {};
  const safe = v => esc(String(v ?? '').trim());
  const val = (v, placeholder='________________________') => safe(v) || placeholder;
  const fmtDate = v => v ? contractDateText(v) : '__.__.20__';
  const edit = (v, placeholder='____________________') => `<span class="editable" contenteditable="true" spellcheck="false" title="Таҳрирлаш учун босинг">${val(v, placeholder)}</span>`;
  const row = (label, value) => `<tr><th>${safe(label)}</th><td>${value}</td></tr>`;
  const studentName = val(s.name);
  const fee = money(s.fee);
  const courseStart = fmtDate(s.courseStart || s.join);
  const courseEnd = fmtDate(s.courseEnd);
  const category = val(g.category);
  const contractNumber = val(s.contractNo, '____________');
  const date = fmtDate(s.contractDate);
  const title = `Шартнома ${contractNumber} — ${studentName}`;
  const printHtml = `<!doctype html>
<html lang="uz-Cyrl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<style>
@page{size:A4;margin:15mm 16mm}
*{box-sizing:border-box}body{font-family:"Times New Roman",serif;color:#162235;font-size:11.5pt;line-height:1.37;margin:0 auto;max-width:900px;background:white}
.toolbar{position:sticky;top:0;z-index:10;padding:12px 18px;background:#eaf2ff;border-bottom:1px solid #c1d1ee;display:flex;align-items:center;justify-content:space-between;gap:12px;font:13px system-ui,sans-serif}
.toolbar p{margin:0;max-width:690px}.toolbar button{border:0;background:#144aab;color:#fff;border-radius:7px;padding:10px 16px;white-space:nowrap;cursor:pointer;font-weight:700}
.paper{padding:20px 23px 35px}h1{font-size:14pt;text-align:center;line-height:1.22;margin:15px 0 12px}h2{font-size:11.5pt;text-align:center;letter-spacing:.25px;margin:16px 0 7px}h3{font-size:11pt;margin:10px 0 5px}p{margin:6px 0;text-align:justify}.center{text-align:center}.meta{display:flex;justify-content:space-between;gap:14px;margin-bottom:13px}.meta p{margin:0}.editable{display:inline-block;min-width:55px;padding:0 3px;border-bottom:1px dashed #5c89c5;background:#f7faff;cursor:text}.editable:focus{outline:2px solid #4678cd}.minor{font-size:9.8pt;color:#536477}.warning{font-size:12px;color:#9d3316;font-family:system-ui,sans-serif;text-align:left;padding:7px 10px;border:1px solid #efd0c9;background:#fff7f3;border-radius:6px}.two{display:grid;grid-template-columns:1fr 1fr;gap:16px}.sign{border:1px solid #9aa7ba;padding:9px;min-height:135px}.sign p{text-align:left}.page{break-before:page;page-break-before:always}table{border-collapse:collapse;width:100%;font-size:10pt;margin:8px 0}th,td{border:1px solid #66748b;padding:5px 7px;vertical-align:top}th{background:#f2f5fa;text-align:left;width:33%}.att th{width:auto}.att td{height:30px}small{font-size:9pt}ul{margin:5px 0;padding-left:24px}li{margin-bottom:3px}
@media print{body{max-width:none}.toolbar{display:none!important}.paper{padding:0}.editable{background:transparent;border-bottom:1px solid #aaa}.warning{display:none}h2,h3{break-after:avoid}p,tr,.sign{break-inside:avoid}table{break-inside:auto}}
@media(max-width:700px){.meta,.two{display:block}.sign{margin-bottom:12px}.toolbar{position:relative;display:block}.toolbar button{margin-top:10px;width:100%}.paper{padding:13px}}
</style></head><body>
<div class="toolbar"><p><b>Шартнома чоп этиш / PDF</b><br>Кўк чизиқли жойларни босиб, ташкилот реквизитлари, хизмат ҳажми ва бошқа бўш майдонларни тўлдиринг. Кейин «Чоп этиш / PDF»ни босинг. PDF учун принтер танловида «Save as PDF / PDF сифатида сақлаш»ни танланг.</p><button id="contractPrint" type="button">Чоп этиш / PDF</button></div>
<main class="paper">
<h1>ҲАЙДОВЧИЛАРНИ ТАЙЁРЛАШ БЎЙИЧА<br>ҲАҚ ЭВАЗИГА ТАЪЛИМ ХИЗМАТЛАРИ КЎРСАТИШ ШАРТНОМАСИ</h1>
<div class="meta"><p>№ <b>${contractNumber}</b></p><p><b>${date}</b></p><p>${edit('', 'шаҳар / туман')}</p></div>
<p>«${edit('', 'ташкилотнинг тўлиқ юридик номи')}» (кейинги ўринларда <b>Ижрочи</b>), СТИР: ${edit('', 'СТИР')}, лицензия/рухсат реквизитлари: ${edit('', 'рақами ва санаси')}, директор ${edit('', 'директор Ф.И.Ш.')} номидан, Устав асосида ҳаракат қилувчи бир томондан, ва фуқаро <b>${studentName}</b> (кейинги ўринларда <b>Ўқувчи</b>), иккинчи томондан, ушбу шартномани туздилар.</p>
<p>Ўқувчининг туғилган санаси: ${fmtDate(s.birthDate)}; паспорт/ID: <b>${val(s.passport)}</b>; ЖШШИР: <b>${val(s.pinfl)}</b>. Қонуний вакил (талаб қилинса): ${edit(s.payerName)}.</p>
<h2>1. ШАРТНОМА ПРЕДМЕТИ</h2>
<p><b>1.1.</b> Ижрочи Ўқувчига ${category} тоифасидаги ҳайдовчиликка тайёрлаш/қайта тайёрлаш бўйича 1-иловада кўрсатилган хизматларни белгиланган дастур, муддат ва ҳажмда кўрсатади. Ўқувчи хизматларни қабул қилади ва тўловни амалга оширади.</p>
<p><b>1.2.</b> Таълим хизмати тури: ${edit('', 'назарий / амалий / комплекс')}. Ўқув гуруҳи: <b>${val(g.name)}</b>. Ўқиш бошланиши: <b>${courseStart}</b>, режалаштирилган тугаши: <b>${courseEnd}</b>. Машғулот манзили: ${edit('', 'аниқ манзил')}.</p>
<p><b>1.3.</b> Назарий дарслар, амалиёт соатлари ва қўшимча хизматлар 1-иловада белгиланади. Қонунчилик мустақил назарий тайёргарликка рухсат берган тоифада назария фақат келишилган бўлса, ҳақ эвазига хизмат таркибига киради.</p>
<p><b>1.4.</b> Ижрочи гувоҳнома олиш ёки ташқи имтиҳондан муваффақиятли ўтишга кафолат бермайди; у келишилган таълим хизматларини сифатли бажаришга жавобгардир.</p>
<h2>2. ИЖРОЧИНИНГ ҲУҚУҚ ВА МАЖБУРИЯТЛАРИ</h2>
<p><b>2.1.</b> Ижрочи малака талабларига мос ўқитувчи ва йўриқчилар, тегишли транспорт воситалари билан таъминлайди, дарс жадвали ва хавфсизлик қоидаларини маълум қилади, ўтилган машғулотларни ҳисобга олади.</p>
<p><b>2.2.</b> Ижрочи айби билан ўтмаган машғулотлар қўшимча ҳақсиз қайта ўтилади ёки қонунчиликка мувофиқ ҳисоб-китоб қилинади. Ижрочи ўқувчидан зарур ҳужжатлар, қоидаларга риоя қилиш ва ўз вақтида тўлов талаб қилишга ҳақли.</p>
<h2>3. ЎҚУВЧИНИНГ ҲУҚУҚ ВА МАЖБУРИЯТЛАРИ</h2>
<p><b>3.1.</b> Ўқувчи ишончли ҳужжатларни тақдим этади, тўлов графигига амал қилади, машғулотларга қатнашади, йўл ҳаракати ва техника хавфсизлиги талабларига ҳамда йўриқчи кўрсатмаларига риоя қилади.</p>
<p><b>3.2.</b> Ўқувчи дарс, тўлов ва ўзлаштириш натижалари бўйича ахборот олишга, сифатсиз ёки бажарилмаган хизматлар бўйича қонуний талаб қўйишга, қонунчиликдаги тартибда шартномани бекор қилишга ҳақли.</p>
<h2>4. НАРХ ВА ТЎЛОВЛАР</h2>
<p><b>4.1.</b> Шартнома қиймати: <b>${fee}</b>. Тўловнинг охирги муддати: ${fmtDate(s.paymentDue)}. Тўлов тартиби: ${edit(s.paymentTerms, '1-иловада белгиланади')}.</p>
<p><b>4.2.</b> Тўлов банк, расмий касса ёки қонуний тўлов тизимлари орқали амалга оширилиб, тўлов ҳужжати билан тасдиқланади. Нарх бир томонлама ўзгартирилмайди; ўзгаришлар қонунчилик доирасида ёзма қўшимча келишув билан расмийлаштирилади.</p>
<p><b>4.3.</b> Тўлов кечикса, Ижрочи қарз ва тўловни амалга ошириш муддатини билдириб огоҳлантиради. Машғулотларни тўхтатиш ёки шартномани бекор қилиш фақат қонуний асосда амалга оширилади.</p>
<h2>5. ДАВОМАТ, ХАВФСИЗЛИК ВА ЗАРАР</h2>
<p><b>5.1.</b> Мажбурий амалий машғулотлар тўлиқ ўтилиши, давомат ва амалий соатлар журнал ёки қонуний электрон ҳисобда қайд этилиши керак. Дарсга келолмаслик ҳақида имкони борича 24 соат олдин маълум қилинади. Сабабли дарс қолдириш алоҳида кўриб чиқилади.</p>
<p><b>5.2.</b> Амалиёт фақат йўриқчи назоратида ўтказилади. Мастлик ёки хавфли хатти-ҳаракатларда йўриқчи машғулотни тўхтатиши ва ҳолатни расмий қайд этиши мумкин.</p>
<p><b>5.3.</b> ЙТҲ ёки зарарда томонларнинг айби, сабабий боғлиқлик, суғурта ва далиллар қонунчилик асосида баҳоланади. Ўқувчига ҳар қандай зарар учун автоматик ёки чекланмаган жавобгарлик юкланмайди.</p>
<h2>6. ЯКУНИЙ БАҲОЛАШ ВА ҲУЖЖАТЛАР</h2>
<p><b>6.1.</b> Дастур ва зарур баҳолашлар бажарилганидан сўнг натижалар амалдаги тартибда расмийлаштирилади. Ташқи имтиҳон, давлат божи ва қўшимча хизматлар нархга кириши/кирмаслиги 1-иловада алоҳида кўрсатилади.</p>
<h2>7. БЕКОР ҚИЛИШ ВА ҚАЙТАРИМ</h2>
<p><b>7.1.</b> Шартнома ёзма келишув ёки қонунчиликдаги асослар билан бекор қилиниши мумкин. Муддатидан олдин тугаса, амалий кўрсатилган хизматлар, ўтилмаган машғулотлар ва қонунан ҳисобга олинадиган харажатлар бўйича алоҳида ёзма ҳисоб-китоб қилинади. Асоссиз маблағ ушлаб қолиш тақиқланади.</p>
<p><b>7.2.</b> Хизматни кўрсатмаслик ёки сифатсиз кўрсатишда истеъмолчининг қонуний талаблари сақланади. Қайтариладиган маблағ ва муддат қонунчилик асосида аниқланади.</p>
<h2>8. ШАХСГА ДОИР МАЪЛУМОТЛАР</h2>
<p><b>8.1.</b> Ижрочи шахсий маълумотлардан шартномани бажариш, қонуний ҳисобот ва ваколатли тизимга ахборот тақдим этиш мақсадларида, қонунчилик доирасида фойдаланади. Реклама мақсадида қайта ишлаш алоҳида ихтиёрий розиликни талаб қилади.</p>
<h2>9. НИЗОЛАР ВА ЯКУНИЙ ҚОИДАЛАР</h2>
<p><b>9.1.</b> Низолар музокара ва ёзма мурожаат билан ҳал этилади; келишув бўлмаса, ваколатли орган ёки судга мурожаат қилиш ҳуқуқи сақланади.</p>
<p><b>9.2.</b> Енгиб бўлмас куч ҳолатлари қонунчилик асосида баҳоланади. Шартнома имзоланган пайтдан кучга киради, икки тенг юридик кучга эга нусхада тузилади. 1-илова унинг ажралмас қисмидир.</p>
<h2>10. ТОМОНЛАР РЕКВИЗИТЛАРИ ВА ИМЗОЛАР</h2>
<div class="two"><div class="sign"><b>ИЖРОЧИ — АВТОМАКТАБ</b><p>Юридик номи: ${edit('', 'МЧЖ номи')}</p><p>СТИР: ${edit('', 'рақам')}</p><p>Манзил: ${edit('', 'юридик манзил')}</p><p>Банк: ${edit('', 'банк номи')}</p><p>Ҳ/р: ${edit('', 'ҳисоб рақами')}</p><p>МФО: ${edit('', 'МФО')}</p><p>Телефон: ${edit('', '+998 ...')}</p><p>Директор: ${edit('', 'Ф.И.Ш.')}</p><p>Имзо: ____________________</p></div>
<div class="sign"><b>ЎҚУВЧИ / ҚОНУНИЙ ВАКИЛ</b><p>Ф.И.Ш.: ${studentName}</p><p>ЖШШИР: ${val(s.pinfl)}</p><p>Паспорт/ID: ${val(s.passport)}</p><p>Манзил: ${val(s.address)}</p><p>Телефон: ${val(s.phone)}</p><p>Вакил: ${val(s.payerName, '—')}</p><p>Тел.: ${val(s.payerPhone, '—')}</p><p>Имзо: ____________________</p></div></div>
<section class="page"><h2>1-ИЛОВА. ХИЗМАТ СПЕЦИФИКАЦИЯСИ ВА ТЎЛОВ ГРАФИГИ</h2>
<p class="center">${date} йилдаги № ${contractNumber} шартномага</p>
<table>${row('Ўқувчи Ф.И.Ш.',studentName)}${row('Ўқув гуруҳи',val(g.name))}${row('Транспорт тоифаси',category)}${row('Хизмат тури',edit('', 'назарий / амалий / комплекс'))}${row('Назарий соатлар',edit('', 'академик соат / кирмайди'))}${row('Амалий соатлар',edit('', 'академик соат'))}${row('Машғулот кунлари',val(g.days))}${row('Дарс вақти',val(g.time))}${row('Бошланиш / тугаш',`${courseStart} — ${courseEnd}`)}${row('Транспорт воситаси',edit('', 'модел / тур'))}${row('Дастур ва манзил',edit('', 'дастур, манзил'))}${row('Шартнома суммаси',fee)}${row('Нархга кирмайдиган харажатлар',edit('', 'имтиҳон, давлат божи ва бошқалар'))}${row('Қўшимча дарс қиймати',edit('', 'сўм/соат ёки йўқ'))}${row('Тўлов тартиби',edit(s.paymentTerms, 'бўлиб тўлаш тартиби'))}</table>
<h3>Тўлов графиги</h3><table class="att"><thead><tr><th>№</th><th>Тўлов муддати</th><th>Сумма (сўм)</th><th>Изоҳ</th></tr></thead><tbody><tr><td>1</td><td>${edit(s.paymentDue,'__.__.20__')}</td><td>${edit(String(Number(s.fee || 0)), 'сумма')}</td><td>${edit('', 'бир йўла / бўлиб')}</td></tr><tr><td>2</td><td>${edit('', '__.__.20__')}</td><td>${edit('', 'сумма')}</td><td></td></tr><tr><td>3</td><td>${edit('', '__.__.20__')}</td><td>${edit('', 'сумма')}</td><td></td></tr></tbody></table>
<p class="minor">Агар тўлов бўлиб тўланса, суммаларни мувофиқлаштиринг. Графикдаги жами тўлов шартнома суммасига тенг бўлиши керак.</p>
<p>Ижрочи вакили: _____________________ &nbsp;&nbsp; Ўқувчи (вакили): _____________________</p></section>
<section class="page"><h2>2-ИЛОВА. АМАЛИЙ МАШҒУЛОТЛАР ҲИСОБ ВАРАҒИ</h2><p>Шартнома № ${contractNumber} &nbsp; Ўқувчи: <b>${studentName}</b></p>
<table class="att"><thead><tr><th>№</th><th>Сана</th><th>Машғулот соати</th><th>Мавзу/йўналиш</th><th>Йўриқчи имзоси</th><th>Ўқувчи имзоси</th></tr></thead><tbody>${Array.from({length:12},(_,i)=>`<tr><td>${i+1}</td><td></td><td></td><td></td><td></td><td></td></tr>`).join('')}</tbody></table><p>Жами амалий машғулот соати: ${edit('', '_____ соат')}. &nbsp;&nbsp; Йўриқчи имзоси: ____________</p><p>Ўқувчи имзоси: ______________</p>
<p class="minor">Ушбу варақ намунавий ҳисоб шакли. Давоматни юритишда амалдаги талаблар ҳам сақланади.</p></section>
</main></body></html>`;
  const w = window.open('', '_blank');
  if (!w) { toast('Ойна очиш браузер томонидан блокланган. Pop-up рухсатини беринг.', true); return; }
  w.document.open();
  w.document.write(printHtml);
  w.document.close();
  const printBtn = w.document.getElementById('contractPrint');
  if (printBtn) printBtn.addEventListener('click', () => { w.focus(); w.print(); });
}
